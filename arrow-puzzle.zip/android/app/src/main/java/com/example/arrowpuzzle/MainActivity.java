package com.example.arrowpuzzle;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "UnityAdsBridge";
    
    // Real Unity Ads Configuration
    public static final String GAME_ID = "6094029";
    public static final String PLACEMENT_INTERSTITIAL = "Interstitial_Android";
    public static final String PLACEMENT_REWARDED = "Rewarded_Android";
    public static final boolean TEST_MODE = false; // Real Production Ads

    private WebView webView;
    private final Set<String> loadedPlacements = Collections.synchronizedSet(new HashSet<>());
    private boolean isUnityAdsInitialized = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on during gameplay
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Fullscreen immersive mode
        hideSystemUI();

        // Initialize Unity Ads SDK immediately on app startup
        initUnityAds();

        // Setup Hardware-Accelerated WebView for the game
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Enable hardware acceleration
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // Attach JavaScript Bridge interface
        webView.addJavascriptInterface(new UnityAdsJSInterface(), "AndroidUnityAds");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Game loaded successfully: " + url);
                // Inform web layer that native Android Unity Ads bridge is active
                evaluateJs("console.log('[Native] AndroidUnityAds bridge connected. Real Unity Ads active.');");
            }
        });

        // Load the bundled game HTML
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    /**
     * Initialize Unity Ads SDK with real Game ID: 6094029
     */
    private void initUnityAds() {
        if (isUnityAdsInitialized) return;

        Log.d(TAG, "Initializing Unity Ads SDK natively with Game ID: " + GAME_ID + " (testMode=" + TEST_MODE + ")");
        UnityAds.initialize(this, GAME_ID, TEST_MODE, new IUnityAdsInitializationListener() {
            @Override
            public void onInitializationComplete() {
                isUnityAdsInitialized = true;
                Log.d(TAG, "Unity Ads SDK initialized successfully! Preloading ads...");
                loadAd(PLACEMENT_INTERSTITIAL);
                loadAd(PLACEMENT_REWARDED);
            }

            @Override
            public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                isUnityAdsInitialized = false;
                Log.e(TAG, "Unity Ads initialization failed: " + message + ", error: " + error);
            }
        });
    }

    private void loadAd(final String placementId) {
        Log.d(TAG, "Preloading placement: " + placementId);
        UnityAds.load(placementId, new IUnityAdsLoadListener() {
            @Override
            public void onUnityAdsAdLoaded(String placement) {
                Log.d(TAG, "Unity Ad loaded successfully: " + placement);
                loadedPlacements.add(placement);
            }

            @Override
            public void onUnityAdsFailedToLoad(String placement, UnityAds.UnityAdsLoadError error, String message) {
                Log.e(TAG, "Unity Ad failed to load: " + placement + ", error: " + error + ", message: " + message);
                loadedPlacements.remove(placement);
            }
        });
    }

    private void evaluateJs(final String script) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (webView != null) {
                    webView.evaluateJavascript(script, null);
                }
            }
        });
    }

    private final IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
        @Override
        public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
            Log.e(TAG, "Ad failed to display: " + placementId + " [" + error + "]: " + message);
            loadedPlacements.remove(placementId);
            evaluateJs("window.onUnityAdFinished && window.onUnityAdFinished('" + placementId + "', 'FAILED');");
            // Reload for next time
            loadAd(placementId);
        }

        @Override
        public void onUnityAdsShowStart(String placementId) {
            Log.d(TAG, "Ad playback started: " + placementId);
            loadedPlacements.remove(placementId);
        }

        @Override
        public void onUnityAdsShowClick(String placementId) {
            Log.d(TAG, "User clicked on ad: " + placementId);
        }

        @Override
        public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
            Log.d(TAG, "Ad display completed: " + placementId + " state: " + state);
            String result = (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) ? "COMPLETED" : "SKIPPED";
            evaluateJs("window.onUnityAdFinished && window.onUnityAdFinished('" + placementId + "', '" + result + "');");
            // Automatically reload the placement so the next ad is instantly ready
            loadAd(placementId);
        }
    };

    /**
     * JavaScript Interface exposed to the React web app as `window.AndroidUnityAds`
     */
    public class UnityAdsJSInterface {

        @JavascriptInterface
        public void initialize(String id, boolean test) {
            Log.d(TAG, "JS called initialize(" + id + ", " + test + ")");
            if (!isUnityAdsInitialized) {
                initUnityAds();
            }
        }

        @JavascriptInterface
        public void showInterstitial(final String placementId) {
            Log.d(TAG, "JS requested showInterstitial: " + placementId);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String targetPlacement = (placementId != null && !placementId.isEmpty()) 
                            ? placementId : PLACEMENT_INTERSTITIAL;
                    UnityAds.show(MainActivity.this, targetPlacement, new UnityAdsShowOptions(), showListener);
                }
            });
        }

        @JavascriptInterface
        public void showRewarded(final String placementId) {
            Log.d(TAG, "JS requested showRewarded: " + placementId);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String targetPlacement = (placementId != null && !placementId.isEmpty()) 
                            ? placementId : PLACEMENT_REWARDED;
                    UnityAds.show(MainActivity.this, targetPlacement, new UnityAdsShowOptions(), showListener);
                }
            });
        }

        @JavascriptInterface
        public boolean isReady(String placementId) {
            String targetPlacement = (placementId != null && !placementId.isEmpty()) 
                    ? placementId : PLACEMENT_REWARDED;
            boolean ready = loadedPlacements.contains(targetPlacement);
            Log.d(TAG, "isReady(" + targetPlacement + ") = " + ready);
            return ready;
        }

        @JavascriptInterface
        public boolean isNative() {
            return true;
        }
    }
}
