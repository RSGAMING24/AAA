import { LevelData } from '../types';

export const defaultLevels: LevelData[] = [
  {
    "id": "level_1",
    "number": 1,
    "gridSize": 5,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_1_3745",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1_654",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_1_7647",
        "x": 0,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1_3",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1_4064",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_4_1_5747",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1_3497",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_2",
    "number": 2,
    "gridSize": 5,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_2_9101",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_2_861",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_2_8410",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_2_4652",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_5_2_2614",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_2_4839",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_2_3308",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_3",
    "number": 3,
    "gridSize": 4,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_3_8360",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_3_1812",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_3_2330",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_1_3_3975",
        "x": 1,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_3_6548",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_3_4657",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_4",
    "number": 4,
    "gridSize": 5,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_4_8235",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_4_5633",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_4_6070",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_4_4289",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_4_9083",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_4_9825",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_4_4232",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_5",
    "number": 5,
    "gridSize": 5,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_5_1710",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_5_8182",
        "x": 1,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_5_5_7722",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_5_8004",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_5_4875",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_5_8300",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_5_754",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_6",
    "number": 6,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_6_3138",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_6_3421",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_6_5582",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_6_4585",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_6_8166",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_0_6_4121",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_6_2099",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_6_6_7322",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_6_6038",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_6_1969",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_7",
    "number": 7,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_7_2676",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_7_3238",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_7_573",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_7_1715",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_7_6849",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_6_7_7108",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_7_6490",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_7_4227",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_8_7_2254",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_7_8540",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_8",
    "number": 8,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_8_6521",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_0_8_4760",
        "x": 2,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_8_5713",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_8_2740",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_8_9988",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_8_8405",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_8_951",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_8_6001",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_8_6389",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_8_7900",
        "x": 0,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_9",
    "number": 9,
    "gridSize": 6,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_9_2483",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_1_9_7794",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_9_1151",
        "x": 0,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_9_8822",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_9_4173",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_5_9_6588",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_9_6778",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_9_7170",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_9_8156",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_9_5174",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_9_5534",
        "x": 2,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_9_4966",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_10",
    "number": 10,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_10_1437",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_10_9354",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_10_1426",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_10_583",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_4_10_2951",
        "x": 1,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_10_6241",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_10_2798",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_8_10_2938",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_10_3792",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_10_2183",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_11",
    "number": 11,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_11_7113",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_11_1787",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_11_4680",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_11_9708",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_11_7794",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_11_5292",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_11_3785",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_5_11_8161",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_11_2070",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_11_6841",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_12",
    "number": 12,
    "gridSize": 6,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_12_3884",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_12_3311",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_12_8001",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_12_2045",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_7_12_2070",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_12_2147",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_12_80",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_12_2178",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_12_5210",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_12_1412",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_12_838",
        "x": 0,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_12_778",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_13",
    "number": 13,
    "gridSize": 6,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_1_13_2775",
        "x": 5,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_13_2837",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_13_1273",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_13_4608",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_13_324",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_13_9255",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_13_132",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_13_4203",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_13_9612",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_13_8588",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_13_9940",
        "x": 3,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_9_13_4704",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_14",
    "number": 14,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_14_9178",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_14_5250",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_14_6321",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_3_14_2873",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_6_14_7031",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_14_2151",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_14_4312",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_14_9491",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_4_14_3056",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_14_4020",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_15",
    "number": 15,
    "gridSize": 6,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_15_8367",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_15_7413",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_15_8280",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_10_15_1678",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_15_4214",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_15_1343",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_15_6430",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_15_938",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_15_391",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_15_8017",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_15_6234",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_9_15_1395",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_16",
    "number": 16,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_16_525",
        "x": 3,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_16_7414",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_16_7426",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_16_4700",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_16_1967",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_16_8958",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_16_457",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_16_8614",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_1_16_9934",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_16_4193",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_16_5029",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_16_7271",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_17",
    "number": 17,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_17_7357",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_17_3698",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_10_17_9164",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_17_9564",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_17_9213",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_17_5010",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_17_9922",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_17_5223",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_17_2724",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_17_3578",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_17_637",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_17_8379",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_18",
    "number": 18,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_18_1416",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_18_6371",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_12_18_4458",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_18_3072",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_18_62",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_18_617",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_18_3907",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_18_5618",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_18_1743",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_18_5578",
        "x": 1,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_18_906",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_18_7555",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_3_18_6890",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_18_3555",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_18_3405",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_19",
    "number": 19,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_19_298",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_19_7886",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_19_1663",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_19_5885",
        "x": 4,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_19_2612",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_19_6803",
        "x": 3,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_19_2444",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_19_8266",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_19_5535",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_19_3044",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_19_302",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_11_19_7811",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_20",
    "number": 20,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_1_20_7469",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_9_20_6472",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_20_6905",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_20_7233",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_20_3313",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_20_4431",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_20_3774",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_20_644",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_20_3723",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_10_20_5573",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_20_9208",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_14_20_7802",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_20_6585",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_6_20_3433",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_20_6107",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_21",
    "number": 21,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_21_4463",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_21_5566",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_21_7926",
        "x": 3,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_21_7222",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_21_2142",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_21_676",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_4_21_7581",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_21_6327",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_21_9299",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_21_4326",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_21_4934",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_21_4780",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_22",
    "number": 22,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_10_22_8492",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_22_2408",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_22_8933",
        "x": 0,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_22_9198",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_8_22_7562",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_22_5815",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_7_22_149",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_22_2154",
        "x": 2,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_22_4202",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_22_9038",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_22_5551",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_5_22_9264",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_22_3198",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_22_3815",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_22_4465",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_23",
    "number": 23,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_23_3433",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_23_4389",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_23_9265",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_23_2010",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_23_57",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_23_5836",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_23_5093",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_23_5823",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_23_2019",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_23_4317",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_23_766",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_0_23_8044",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 3
      }
    ]
  },
  {
    "id": "level_24",
    "number": 24,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_24_8664",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_24_9521",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_24_4650",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_6_24_6614",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_24_158",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_24_2214",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_24_8008",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_24_9088",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_24_9837",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_24_9457",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_11_24_7432",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_24_8217",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_25",
    "number": 25,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_25_6876",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_25_8522",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_25_3849",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_12_25_2486",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_25_8799",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_25_5941",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_25_8820",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_25_4565",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_14_25_7848",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_1_25_6324",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_25_9578",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_25_4843",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_25_2667",
        "x": 5,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_25_7966",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_25_6333",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_26",
    "number": 26,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_12_26_8607",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_26_6601",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_26_9405",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_26_3303",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_26_1409",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_26_7397",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_26_1326",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_26_5783",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_26_8308",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_26_7242",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_26_1251",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_26_6239",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_26_6221",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_26_4659",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_26_1877",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_15_26_5811",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_26_1223",
        "x": 1,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_26_8620",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_27",
    "number": 27,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_12_27_8320",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_27_528",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_27_2198",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_1_27_4235",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_27_7539",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_27_9587",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_27_8740",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_27_134",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_27_6217",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_27_5610",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_27_8982",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_11_27_7589",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_27_1792",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_16_27_2900",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_18_27_8768",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_27_8900",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_27_6639",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_27_3317",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_27_3227",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_27_2049",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_14_27_8454",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_28",
    "number": 28,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_11_28_1974",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_28_7080",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_28_3561",
        "x": 2,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_28_7298",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_9_28_1593",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_5_28_4747",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_28_2565",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_28_418",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_28_4765",
        "x": 0,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_28_299",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_28_2511",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_28_1887",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_28_6682",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_28_9195",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_28_5400",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_28_1948",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_28_7479",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_29",
    "number": 29,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_29_128",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_29_9742",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_29_6892",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_29_1468",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_29_3486",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_29_8534",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_16_29_4891",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_29_1135",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_29_4272",
        "x": 2,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_29_3397",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_29_9204",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_29_8249",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_13_29_5015",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_29_8286",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_29_6097",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_29_4719",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_9_29_8806",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_1_29_9445",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_30",
    "number": 30,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_30_8374",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_30_6088",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_5_30_6792",
        "x": 3,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_30_8697",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_30_7758",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_30_6644",
        "x": 0,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_30_299",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_30_3069",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_30_7196",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_30_6588",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_30_2161",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_30_6280",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_30_1511",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_30_6512",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_30_6774",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_30_2939",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_30_9400",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_30_3074",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_31",
    "number": 31,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_31_2160",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_31_4041",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_31_2096",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_31_5837",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_15_31_3577",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_31_6668",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_14_31_6494",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_31_4827",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_31_3546",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_31_4748",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_31_4829",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_5_31_8010",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_31_5385",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_31_2763",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_31_7550",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_12_31_9873",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_31_323",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_31_7406",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_32",
    "number": 32,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_32_9023",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_32_2048",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_32_815",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_32_2434",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_19_32_3835",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_32_7030",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_32_9745",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_32_4898",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_0_32_4869",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_16_32_3707",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_32_3807",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_32_2391",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_1_32_1260",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_32_5804",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_32_8550",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_32_9222",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_2_32_1927",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_32_4243",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_32_4112",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_13_32_1762",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_32_2318",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_33",
    "number": 33,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_33_1502",
        "x": 4,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_33_6395",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_33_7801",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_33_2505",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_33_4323",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_33_1007",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_33_222",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_33_2201",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_18_33_6111",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_33_9933",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_33_3361",
        "x": 5,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_33_8073",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_33_4751",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_16_33_3127",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_33_8698",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_33_1712",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_11_33_4731",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_33_5988",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_33_6909",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_3_33_8296",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_33_4196",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      }
    ]
  },
  {
    "id": "level_34",
    "number": 34,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_34_3078",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_34_4412",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_14_34_1038",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_2_34_6527",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_34_9406",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_34_3285",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_34_5011",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_34_7715",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_34_8461",
        "x": 2,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_17_34_1445",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_34_9549",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_34_9128",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_34_50",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_34_3475",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_6_34_357",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_7_34_2913",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_34_7456",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_34_5368",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_35",
    "number": 35,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_35_770",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_35_2077",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_9_35_7998",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_35_3062",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_35_6216",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_35_9529",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_35_5463",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_35_4295",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_35_7026",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_4_35_4840",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_35_7899",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_35_2980",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_35_2345",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_35_7691",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_35_6389",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_35_5337",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_35_1601",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_35_4366",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_36",
    "number": 36,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_36_2204",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_36_6908",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_36_3846",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_36_7449",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_36_6266",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_36_431",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_36_9770",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_17_36_2605",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_36_4669",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_36_5350",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_36_1468",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_13_36_2000",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_9_36_8489",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_36_5216",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_6_36_4602",
        "x": 1,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_36_3767",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_36_4322",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_19_36_9111",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_36_901",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_36_1030",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_18_36_7207",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_37",
    "number": 37,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_15_37_1216",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_37_8551",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_14_37_7753",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_19_37_1307",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_37_8230",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_37_8931",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_37_6215",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_37_7204",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_12_37_5277",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_37_101",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_37_1242",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_37_6892",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_37_4269",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_37_6004",
        "x": 4,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_37_9101",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_37_282",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_37_2573",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_20_37_2773",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_37_719",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_37_2874",
        "x": 2,
        "y": 4,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_6_37_5338",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_38",
    "number": 38,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_12_38_8748",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_38_6040",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_38_9641",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_38_9370",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_38_9167",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_3_38_8986",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_9_38_1461",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_17_38_1879",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_38_4948",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_38_1790",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_38_70",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_38_7802",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_38_6388",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_6_38_3780",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_18_38_1394",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_38_4428",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_38_710",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_38_6586",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_38_1938",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_38_6339",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_38_6157",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      }
    ]
  },
  {
    "id": "level_39",
    "number": 39,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_39_9687",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_39_7321",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_39_2817",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_39_3692",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_39_6503",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_3_39_451",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_39_4758",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_39_7660",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_39_2505",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_39_9524",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_8_39_3878",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_39_2232",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_17_39_5204",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_39_5354",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_39_9941",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_39_9954",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_39_2450",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_39_8026",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_39_4730",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_39_9612",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_39_634",
        "x": 6,
        "y": 6,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_40",
    "number": 40,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_40_7002",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_40_3640",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_40_5091",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_40_5601",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_40_163",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_40_8723",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_40_8323",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_1_40_1096",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_40_7012",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_40_9283",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_40_4027",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_40_6432",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_40_9538",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_40_5277",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_17_40_4147",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_40_4870",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_40_526",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_40_30",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_41",
    "number": 41,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_41_2616",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_41_1579",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_41_9473",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_41_6928",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_41_2027",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_26_41_9599",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_41_3409",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_41_8550",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_41_8351",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_3_41_9187",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_41_4967",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_41_9047",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_41_7221",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_41_2486",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_41_6402",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_41_9628",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_41_638",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_18_41_3383",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_41_5419",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_16_41_8003",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_7_41_7250",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_41_616",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_4_41_1803",
        "x": 2,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_41_2594",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_41_4693",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_41_3047",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_41_7097",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_42",
    "number": 42,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_15_42_1123",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_42_6587",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_42_2830",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_42_3166",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_19_42_1038",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_42_7166",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_42_5278",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_42_8733",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_42_9448",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_42_4287",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_42_1069",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_42_2515",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_42_3675",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_42_788",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_42_8382",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_42_916",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_42_2180",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_42_1876",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_42_6038",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_42_8515",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_42_156",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_42_2840",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_42_9682",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_17_42_1095",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_43",
    "number": 43,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_25_43_7056",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_43_8081",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_16_43_3954",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_43_9478",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_14_43_5803",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_43_197",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_43_2771",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_43_7048",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_43_3585",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_43_2468",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_43_8792",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_21_43_5496",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_43_1276",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_43_1199",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_43_9125",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_43_2280",
        "x": 7,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_43_5804",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_43_9323",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_43_5172",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_43_5266",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_43_671",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_43_950",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_43_8904",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_19_43_2486",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_43_1645",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_9_43_4298",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_43_3139",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_15_43_5245",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_44",
    "number": 44,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_44_9884",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_44_4815",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_44_9207",
        "x": 0,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_44_3069",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_44_5740",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_44_5052",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_44_7134",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_44_1137",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_44_2024",
        "x": 4,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_44_7728",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_44_8003",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_44_2450",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_44_1000",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_19_44_358",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_44_6718",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_44_9694",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_44_2495",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_44_859",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_44_6991",
        "x": 6,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_44_2758",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_44_7325",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_44_7097",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_44_2156",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_44_19",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_45",
    "number": 45,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_45_6204",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_45_6911",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_45_4359",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_45_5673",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_45_6396",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_27_45_2028",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_45_7632",
        "x": 6,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_45_6395",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_21_45_946",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_19_45_25",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_45_1250",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_45_2337",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_45_8460",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_23_45_6475",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_45_9128",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_1_45_659",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_12_45_4286",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_45_4721",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_45_674",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_45_5365",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_45_8091",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_45_7381",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_45_5414",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_45_8854",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_45_1062",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_45_8477",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_45_1028",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_22_45_8668",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_46",
    "number": 46,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_18_46_8732",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_46_2357",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_46_2786",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_46_250",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_10_46_9404",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_1_46_6359",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_46_2023",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_12_46_7088",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_46_9770",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_46_9671",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_46_588",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_46_1998",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_46_7635",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_46_1861",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_25_46_590",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_46_5606",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_46_9154",
        "x": 7,
        "y": 6,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_15_46_6563",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_11_46_2390",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_46_2307",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_46_1208",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_46_3276",
        "x": 0,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_46_3239",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_46_6782",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_46_8425",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_46_8356",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_0_46_5741",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_46_5866",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_47",
    "number": 47,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_23_47_5553",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_47_3962",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_47_9688",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_47_9724",
        "x": 6,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_47_5776",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_17_47_8816",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_47_1307",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_47_8741",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_7_47_5547",
        "x": 6,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_47_4034",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_18_47_5737",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_47_4261",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_47_5787",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_47_3674",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_47_525",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_47_3331",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_47_4327",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_47_449",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_47_6396",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_22_47_2713",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_47_122",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_47_9692",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_47_7764",
        "x": 3,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_47_6874",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_48",
    "number": 48,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_48_7170",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_23_48_8596",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_48_5197",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_48_3636",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_48_3735",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_19_48_7140",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_48_6927",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_1_48_9189",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_10_48_1794",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_48_5686",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_48_7159",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_48_3428",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_48_5411",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_48_6674",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_48_6971",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_48_1775",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_48_968",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_48_578",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_2_48_9739",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_48_6056",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_48_1060",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_48_1222",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_48_7000",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_22_48_172",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_49",
    "number": 49,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_49_8910",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_17_49_2490",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_49_5559",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_11_49_5306",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_49_3178",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_22_49_9212",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_49_245",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_23_49_495",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_49_509",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_49_4065",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_49_8724",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_49_2845",
        "x": 5,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_49_3923",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_49_9278",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_49_8104",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_49_5404",
        "x": 3,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_49_3069",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_49_7019",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_6_49_7492",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_49_7543",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_49_4406",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_49_3897",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_16_49_1367",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_49_3678",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      }
    ]
  },
  {
    "id": "level_50",
    "number": 50,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_50_631",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_50_7989",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_50_4759",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_50_2359",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_50_6350",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_23_50_7439",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_50_955",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_11_50_1084",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_50_2602",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_50_7818",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_50_8822",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_50_2284",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_50_6262",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_5_50_2239",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_50_2797",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_7_50_8200",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_16_50_1402",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_50_1222",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_50_8725",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_50_6208",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_19_50_9482",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_50_7268",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_51",
    "number": 51,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_25_51_4106",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_51_2447",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_51_2912",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_51_7905",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_51_840",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_51_2831",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_13_51_1563",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_51_1142",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_22_51_7651",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_51_3786",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_51_643",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_51_2882",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_51_2737",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_17_51_1004",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_51_3378",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_51_2257",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_14_51_6549",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_51_7738",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_51_2445",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_6_51_1943",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_0_51_4584",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_1_51_7424",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_21_51_9761",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_51_8299",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_51_9677",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_51_969",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_5_51_9088",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_7_51_2870",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 3
      }
    ]
  },
  {
    "id": "level_52",
    "number": 52,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_52_2314",
        "x": 2,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_52_7945",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_52_8222",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_11_52_9410",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_15_52_3660",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_23_52_3374",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_52_7839",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_52_8572",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_52_2297",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_52_1804",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_17_52_7140",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_52_4390",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_52_5851",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_52_5686",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_1_52_9527",
        "x": 3,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_19_52_8194",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_52_8893",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_52_6326",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_52_7869",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_52_629",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_52_5884",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_52_5358",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_52_8611",
        "x": 6,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_52_4649",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_53",
    "number": 53,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_11_53_449",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_53_7155",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_53_4616",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_21_53_3566",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_53_6624",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_53_1983",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_53_8877",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_53_9475",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_53_7896",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_53_5889",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_53_4957",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_13_53_9312",
        "x": 6,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_53_553",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_53_9823",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_53_2418",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_20_53_7108",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_53_9495",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_53_3689",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_53_3824",
        "x": 6,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_53_8106",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_53_2831",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_53_4496",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_53_2651",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_53_9916",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_54",
    "number": 54,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_19_54_1485",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_21_54_5691",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_54_3647",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_54_9140",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_54_6035",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_23_54_7494",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_54_5874",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_54_3253",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_54_539",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_54_4066",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_54_2772",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_54_11",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_54_856",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_11_54_9015",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_54_3975",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_54_3687",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_54_1056",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_54_9931",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_54_7121",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_54_5253",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_54_775",
        "x": 6,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_54_9288",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_54_3976",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_54_1491",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_55",
    "number": 55,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_22_55_926",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_55_9873",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_55_2310",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_55_6210",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_55_5808",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_55_770",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_8_55_7449",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_55_8388",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_9_55_7653",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_55_4952",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_55_7627",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_12_55_3120",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_55_3544",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_55_4650",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_55_9082",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_55_7832",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_55_2205",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_55_6117",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_55_6954",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_25_55_5975",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_55_7236",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_55_2005",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_55_4676",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_55_9934",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_16_55_583",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_7_55_2328",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_55_4584",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_0_55_3577",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_56",
    "number": 56,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_56_4514",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_56_2037",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_56_8487",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_56_9294",
        "x": 6,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_56_7703",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_56_8779",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_56_9789",
        "x": 5,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_56_1999",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_56_2801",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_56_1857",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_10_56_8704",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_56_5022",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_20_56_9540",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_56_9631",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_56_6772",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_21_56_4505",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_13_56_956",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_56_4847",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_56_650",
        "x": 6,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_56_4699",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_56_463",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_56_1250",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_56_1141",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_56_5838",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_4_56_6382",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_56_5217",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_56_6788",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_56_1171",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_57",
    "number": 57,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_15_57_9569",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_57_1216",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_57_2036",
        "x": 7,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_57_5252",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_57_2764",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_57_6789",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_57_2065",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_57_5256",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_57_7461",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_3_57_6920",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_12_57_7927",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_22_57_4734",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_17_57_2428",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_57_9007",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_14_57_6684",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_26_57_2271",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_57_3310",
        "x": 4,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_57_9445",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_21_57_6962",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_57_4951",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_18_57_5614",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_57_2321",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_57_6316",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_57_1754",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_24_57_9722",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_57_8293",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_57_5730",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_57_9279",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_58",
    "number": 58,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_58_3661",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_17_58_7819",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_58_1726",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_58_6859",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_58_465",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_58_1684",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_58_3958",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_9_58_710",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_58_2456",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_23_58_3491",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_58_6795",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_1_58_6353",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_20_58_1082",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_58_4348",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_4_58_9892",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_58_5914",
        "x": 4,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_58_6065",
        "x": 6,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_58_6461",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_18_58_6449",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_58_4915",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_19_58_5915",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_58_8815",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_58_1385",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_58_75",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_59",
    "number": 59,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_59_8471",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_4_59_4771",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_59_9505",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_59_3251",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_59_6963",
        "x": 0,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_59_2674",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_59_772",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_59_1242",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_22_59_4558",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_59_1157",
        "x": 3,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_59_7239",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_3_59_4195",
        "x": 2,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_59_61",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_59_7691",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_59_1279",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_59_5596",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_8_59_3598",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_59_8186",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_59_4649",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_59_5808",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_59_5451",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_59_5169",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_20_59_932",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_59_1752",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_0_59_4629",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_59_7659",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_59_9993",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_59_5127",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_60",
    "number": 60,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_60_3769",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_60_7473",
        "x": 7,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_60_5462",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_14_60_3821",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_60_4610",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_60_4676",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_13_60_6802",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_60_8389",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_60_9531",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_60_8896",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_60_9118",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_60_3603",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_60_4900",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_60_190",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_0_60_3531",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_60_3900",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_23_60_6428",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_60_5022",
        "x": 7,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_60_8102",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_60_1753",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_60_9072",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_60_8652",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_60_6380",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_60_5966",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_60_5389",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_20_60_4880",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_60_3266",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_60_7857",
        "x": 5,
        "y": 5,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_61",
    "number": 61,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_61_1249",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_0_61_7407",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_28_61_1939",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_61_1970",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_61_6770",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_16_61_8655",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_20_61_8006",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_61_1243",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_25_61_7284",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_61_5237",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_61_3060",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_61_2422",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_61_4875",
        "x": 5,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_10_61_810",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_61_3260",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_12_61_4306",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_61_1602",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_8_61_5362",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_61_6627",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_61_4014",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_61_4165",
        "x": 3,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_14_61_2438",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_61_8061",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_61_8133",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_9_61_5033",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_13_61_1916",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_61_2493",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_61_430",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_22_61_3702",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_61_4641",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_61_2849",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_62",
    "number": 62,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_27_62_6567",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_62_2694",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_62_516",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_62_4937",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_62_2044",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_62_2994",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_62_9943",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_62_7301",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_62_8779",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_31_62_3994",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_62_3379",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_62_4741",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_62_6889",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_14_62_5476",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_62_3329",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_62_398",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_62_4180",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_62_8306",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_62_7305",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_62_8524",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_62_3260",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_62_7709",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_62_3930",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_62_5725",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_62_9004",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_62_2942",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_15_62_6463",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_62_7574",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_18_62_5685",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_62_329",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_62_3326",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_62_8280",
        "x": 1,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_63",
    "number": 63,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_63_7611",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_11_63_4606",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_63_9569",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_63_9027",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_63_8297",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_63_5885",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_63_7543",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_63_8982",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_63_9980",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_26_63_1090",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_63_6044",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_63_8961",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_63_4650",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_63_1444",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_63_9326",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_63_2930",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_63_3129",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_63_8256",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_6_63_2466",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_63_8550",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_63_9106",
        "x": 5,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_63_406",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_63_3650",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_63_3319",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_16_63_6208",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_63_4739",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_63_7505",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_63_4459",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_63_1884",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_28_63_1511",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_63_2221",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_63_6153",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_64",
    "number": 64,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_64_4299",
        "x": 4,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_6_64_7704",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_64_7010",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_27_64_9789",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_64_6762",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_64_974",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_64_8488",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_64_172",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_64_3875",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_25_64_3163",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_64_6476",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_64_7643",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_64_2398",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_64_5473",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_64_2745",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_19_64_3559",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_64_7368",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_64_4548",
        "x": 2,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_12_64_141",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_64_469",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_30_64_4254",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_64_8895",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_64_8574",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_64_6443",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_64_5075",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_64_782",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_26_64_4592",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_64_8692",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_64_9102",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_64_1504",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_64_3953",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_64_8111",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_65",
    "number": 65,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_24_65_443",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_11_65_1468",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_65_1319",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_65_8295",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_65_3942",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_65_1356",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_65_3925",
        "x": 4,
        "y": 7,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_6_65_538",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_65_9449",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_20_65_328",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_65_6531",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_65_2053",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_65_2530",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_65_2446",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_65_2588",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_65_2928",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_65_8255",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_21_65_2988",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_65_5802",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_5_65_5527",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_13_65_9106",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_65_6808",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_19_65_5641",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_65_5723",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_28_65_9743",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_65_3323",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_65_1725",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_65_1975",
        "x": 7,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_65_4882",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_66",
    "number": 66,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_66_3549",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_7_66_7259",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_10_66_8097",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_66_7558",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_66_1786",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_6_66_9095",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_30_66_5365",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_66_3758",
        "x": 1,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_66_3081",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_66_4329",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_66_4291",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_25_66_3273",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_66_3900",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_22_66_3512",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_66_9386",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_66_5430",
        "x": 5,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_66_3971",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_66_1717",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_66_2775",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_66_9989",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_66_3303",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_66_8317",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_8_66_3817",
        "x": 6,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_66_6682",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_28_66_5764",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_66_6630",
        "x": 0,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_66_5763",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_23_66_4449",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_66_1284",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_15_66_3982",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_66_6686",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_67",
    "number": 67,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_67_2116",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_67_768",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_67_190",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_67_6628",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_8_67_3647",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_67_3979",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_67_8992",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_67_6033",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_24_67_4097",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_67_3843",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_67_3142",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_67_8038",
        "x": 1,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_67_9359",
        "x": 7,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_67_4685",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_19_67_5265",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_13_67_2592",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_67_3336",
        "x": 5,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_67_2037",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_67_1118",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_67_7253",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_22_67_9243",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_67_274",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_67_316",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_67_5551",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_67_2189",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_28_67_991",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_67_411",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_67_1055",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_67_6396",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_67_3230",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_67_6877",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_67_7907",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_68",
    "number": 68,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_68_9159",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_68_9193",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_5_68_6459",
        "x": 0,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_68_8661",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_68_654",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_68_7262",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_68_5870",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_68_3815",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_68_4477",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_68_7016",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_17_68_9792",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_68_803",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_68_3156",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_68_3554",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_68_1963",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_68_7988",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_68_7308",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_6_68_8682",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_15_68_6047",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_68_8888",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_68_1970",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_68_9806",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_12_68_2454",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_3_68_1457",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_27_68_4413",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_68_1830",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_68_3671",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_68_7883",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_68_5306",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_68_9734",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_69",
    "number": 69,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_29_69_6794",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_69_7339",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_5_69_3155",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_69_5067",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_69_2963",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_69_9654",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_69_1073",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_30_69_8716",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_69_4129",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_6_69_8964",
        "x": 0,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_69_6968",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_69_9508",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_69_1666",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_69_4286",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_69_7223",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_69_7620",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_69_7905",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_10_69_3638",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_31_69_8407",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_69_4512",
        "x": 3,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_69_3590",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_25_69_1740",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_69_8177",
        "x": 1,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_15_69_9158",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_69_9793",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_69_2518",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_69_7077",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_69_7151",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_69_1168",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_69_8140",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_69_2407",
        "x": 6,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_69_4785",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_70",
    "number": 70,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_30_70_1117",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_70_785",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_70_2811",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_70_730",
        "x": 0,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_70_8290",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_31_70_9386",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_70_4968",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_28_70_1332",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_70_8796",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_70_5619",
        "x": 6,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_70_960",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_70_5909",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_70_7300",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_70_8228",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_29_70_7331",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_70_5755",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_70_6447",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_70_4466",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_70_7684",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_7_70_7618",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_3_70_2132",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_70_8797",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_17_70_3897",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_70_5325",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_70_4546",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_70_6528",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_70_93",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_70_9302",
        "x": 3,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_70_4514",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_70_8407",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_70_7488",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_70_4389",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_71",
    "number": 71,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_22_71_6053",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_31_71_1289",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_71_9258",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_71_3323",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_71_2470",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_20_71_9314",
        "x": 6,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_71_460",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_30_71_983",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_71_584",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_71_1995",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_71_2827",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_71_5031",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_29_71_1368",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_19_71_9943",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_16_71_6189",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_71_2538",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_71_3191",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_71_4842",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_26_71_8226",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_71_3141",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_71_2297",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_71_9473",
        "x": 6,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_71_5891",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_71_1581",
        "x": 7,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_71_1138",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_71_8888",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_71_7045",
        "x": 5,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_71_1034",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_71_3430",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_71_9728",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_71_1736",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_72",
    "number": 72,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_11_72_2096",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_72_8809",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_72_8081",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_72_5537",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_72_1706",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_72_607",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_72_9332",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_21_72_7229",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_72_2759",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_4_72_1721",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_8_72_894",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_72_243",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_72_8708",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_72_4796",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_15_72_1967",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_72_8369",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_72_6147",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_72_9493",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_72_4962",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_72_1604",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_22_72_1858",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_72_3754",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_18_72_2287",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_20_72_7763",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_72_5257",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_16_72_3664",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_72_935",
        "x": 6,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_72_9964",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_73",
    "number": 73,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_73_175",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_25_73_1410",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_73_7558",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_73_4703",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_73_5009",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_14_73_2360",
        "x": 7,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_73_484",
        "x": 4,
        "y": 6,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_16_73_6831",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_15_73_14",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_73_970",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_73_2181",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_8_73_4351",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_73_4970",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_73_2421",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_73_7946",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_73_9189",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_73_8901",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_28_73_9190",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_73_7859",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_4_73_3922",
        "x": 0,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_73_6421",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_73_3884",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_73_1430",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_73_3776",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_73_7174",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_73_7991",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_73_1028",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_73_9837",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_73_6092",
        "x": 1,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_73_3737",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_30_73_2025",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_73_5806",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_74",
    "number": 74,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_18_74_8939",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_74_7853",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_74_3303",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_74_7601",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_6_74_2189",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_74_1089",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_21_74_460",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_74_8524",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_74_8595",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_74_1396",
        "x": 4,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_74_5982",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_74_2254",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_74_2276",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_31_74_4563",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_30_74_8532",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_74_52",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_74_9884",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_13_74_5207",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_74_2873",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_74_1533",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_74_6671",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_74_2138",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_74_4099",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_25_74_3887",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_74_582",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_24_74_792",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_74_9900",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_74_664",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_74_5239",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_74_5344",
        "x": 7,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_74_4448",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_75",
    "number": 75,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_23_75_4914",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_75_612",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_75_361",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_12_75_2422",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_75_1731",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_75_7480",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_13_75_5028",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_75_3412",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_75_5244",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_75_4068",
        "x": 2,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_75_2583",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_75_4388",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_75_4591",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_75_4035",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_75_5694",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_20_75_3720",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_75_5126",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_75_8148",
        "x": 6,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_7_75_9510",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_11_75_1875",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_29_75_180",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_75_7689",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_75_9267",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_75_2716",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_75_7593",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_75_5975",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_75_1589",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_10_75_4431",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_19_75_9625",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_75_4119",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_75_142",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_9_75_6248",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_76",
    "number": 76,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_76_6591",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_18_76_8176",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_76_1132",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_30_76_6825",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_76_4171",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_4_76_8568",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_76_5029",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_76_9095",
        "x": 2,
        "y": 5,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_28_76_9793",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_76_1632",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_76_4994",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_20_76_2778",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_5_76_2603",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_76_1181",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_25_76_2315",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_76_2164",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_76_262",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_76_9046",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_12_76_749",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_76_522",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_76_3683",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_76_731",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_76_9786",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_76_5089",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_76_8708",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_76_4304",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_76_9295",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_76_7431",
        "x": 7,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_76_411",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_76_3646",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_76_9028",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_76_1153",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_77",
    "number": 77,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_24_77_7692",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_77_4032",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_77_4422",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_77_8824",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_77_1655",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_77_4959",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_77_2649",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_77_7262",
        "x": 7,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_77_846",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_77_270",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_25_77_5457",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_77_7378",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_77_8761",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_3_77_2347",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_77_3632",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_77_7201",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_77_2426",
        "x": 4,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_77_9862",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_77_472",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_77_8293",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_77_1192",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_5_77_2867",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_77_3026",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_77_8661",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_77_6622",
        "x": 1,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_77_7006",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_20_77_9840",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_77_3493",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_77_8373",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_14_77_6338",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_77_5305",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_21_77_764",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_78",
    "number": 78,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_25_78_1140",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_78_7039",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_78_7987",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_78_1686",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_78_8349",
        "x": 6,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_78_9",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_13_78_5390",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_78_8168",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_78_9332",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_78_6649",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_78_7247",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_78_4736",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_78_3434",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_16_78_2800",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_78_5403",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_78_1283",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_78_3414",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_78_8113",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_78_6656",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_78_2288",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_78_2596",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_78_8233",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_78_4850",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_23_78_3818",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_78_3436",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_78_7589",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_78_8406",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_21_78_9382",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_9_78_1097",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_78_9111",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_78_8521",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_30_78_672",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_79",
    "number": 79,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_79_2795",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_79_1523",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_79_4778",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_79_602",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_16_79_3490",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_13_79_7419",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_79_9154",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_79_5569",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_27_79_5014",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_79_7870",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_79_7562",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_79_8686",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_79_3628",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_79_5254",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_79_4489",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_79_302",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_79_9639",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_79_2316",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_79_7587",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_28_79_8497",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_79_7433",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_79_3691",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_79_7667",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_23_79_4220",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_5_79_2617",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_6_79_6429",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_79_514",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_79_6744",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_79_5668",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_79_4575",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_15_79_4102",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_80",
    "number": 80,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_12_80_2795",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_80_9210",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_26_80_7765",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_80_7478",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_80_4353",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_80_5646",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_80_4304",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_80_9436",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_80_6098",
        "x": 5,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_25_80_4744",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_80_2835",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_80_4821",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_80_2185",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_80_8501",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_22_80_3192",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_80_3528",
        "x": 2,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_80_5432",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_80_7108",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_80_2211",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_80_291",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_80_9002",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_80_5196",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_80_5394",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_24_80_8216",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_80_1282",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_23_80_7294",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_80_221",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_30_80_388",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_28_80_6642",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_80_3044",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_14_80_5676",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_80_3047",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_81",
    "number": 81,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_81_5250",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_81_5353",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_81_4713",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_33_81_3732",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_81_8730",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_25_81_5023",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_81_9021",
        "x": 6,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_81_9893",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_81_3966",
        "x": 4,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_81_6688",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_81_7104",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_81_4646",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_10_81_1645",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_21_81_6113",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_81_4593",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_2_81_674",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_26_81_6360",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_81_3316",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_81_7798",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_29_81_9463",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_81_3778",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_81_5554",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_31_81_7702",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_81_6326",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_81_7048",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_15_81_6539",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_81_8990",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_81_6666",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_81_8714",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_81_893",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_23_81_4362",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_81_8873",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_82",
    "number": 82,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_82_7354",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_82_869",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_82_569",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_29_82_2116",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_82_9291",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_82_5177",
        "x": 7,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_82_7365",
        "x": 1,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_24_82_8992",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_36_82_5866",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_82_4957",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_82_8633",
        "x": 5,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_21_82_4592",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_82_8578",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_82_6979",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_82_6484",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_82_7347",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_34_82_3798",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_82_9026",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_82_7755",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_82_1317",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_37_82_4466",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_82_3124",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_82_6041",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_82_2124",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_0_82_4515",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_33_82_425",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_82_5651",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_82_5389",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_82_1936",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_82_790",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_82_7785",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_82_2000",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_82_1908",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_30_82_5556",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_82_396",
        "x": 5,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_82_5253",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_83",
    "number": 83,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_83_7010",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_83_4755",
        "x": 3,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_32_83_1707",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_83_3488",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_83_8882",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_22_83_801",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_17_83_7506",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_83_9188",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_83_726",
        "x": 4,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_83_3871",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_14_83_118",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_31_83_7021",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_83_3649",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_25_83_1574",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_83_1518",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_34_83_9454",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_83_1035",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_4_83_5343",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_13_83_2066",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_23_83_175",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_83_9722",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_83_5418",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_21_83_3360",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_83_4083",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_83_8597",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_83_1089",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_83_8748",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_83_53",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_83_9067",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_83_360",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_83_9093",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_84",
    "number": 84,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_84_1713",
        "x": 3,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_84_2282",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_29_84_2171",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_39_84_4403",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_84_883",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_84_3663",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_84_4007",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_84_6169",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_84_3446",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_84_5588",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_84_1263",
        "x": 4,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_84_8448",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_84_1523",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_84_342",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_84_7685",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_84_4269",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_84_8020",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_22_84_2298",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_84_8407",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_84_2690",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_84_6341",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_5_84_7900",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_84_8009",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_84_7528",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_36_84_5929",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_84_5170",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_84_5239",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_84_1630",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_14_84_963",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_84_4756",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_84_2561",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_84_6848",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_18_84_8838",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_32_84_8357",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_84_752",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_85",
    "number": 85,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_30_85_8484",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_85_9205",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_85_6151",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_19_85_6622",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_85_6173",
        "x": 3,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_85_9237",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_85_7320",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_85_5225",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_0_85_2919",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_35_85_8936",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_85_9755",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_85_2831",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_85_7908",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_1_85_3938",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_85_8793",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_85_7080",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_85_6114",
        "x": 5,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_85_6149",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_36_85_520",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_85_5030",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_85_9776",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_34_85_2134",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_85_1067",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_21_85_7041",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_85_9703",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_85_9953",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_22_85_8930",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_25_85_510",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_85_8000",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_85_5959",
        "x": 7,
        "y": 4,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_10_85_7625",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_14_85_8466",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_85_8796",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_85_3906",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_86",
    "number": 86,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_15_86_8633",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_86_8603",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_86_5510",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_86_1140",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_20_86_6615",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_34_86_6560",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_30_86_2004",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_86_6528",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_86_9217",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_32_86_2836",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_86_4361",
        "x": 3,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_86_2883",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_86_7028",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_13_86_1516",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_33_86_650",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_35_86_7604",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_86_6894",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_28_86_2634",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_86_9640",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_86_6314",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_86_5413",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_31_86_7778",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_86_3763",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_86_7105",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_1_86_1255",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_86_3383",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_86_9455",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_36_86_2142",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_86_9683",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_86_9911",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_86_5279",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_86_6391",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_86_1010",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_86_250",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_86_8129",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_39_86_2021",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_86_5431",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_86_4088",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_87",
    "number": 87,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_35_87_5918",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_87_9805",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_87_4927",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_87_1036",
        "x": 6,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_30_87_5990",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_87_4070",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_26_87_3608",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_87_8890",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_32_87_6253",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_87_7768",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_87_5812",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_87_9203",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_8_87_3717",
        "x": 5,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_87_7054",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_87_9241",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_87_5921",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_1_87_7435",
        "x": 2,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_87_8101",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_28_87_681",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_87_1793",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_87_4380",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_87_4769",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_11_87_5764",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_87_1761",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_87_960",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_87_1898",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_87_1450",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_87_4707",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_87_794",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_87_7346",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_87_595",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_87_8575",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_87_9013",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_87_7697",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 3
      }
    ]
  },
  {
    "id": "level_88",
    "number": 88,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_88_6740",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_88_9802",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_88_112",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_88_4153",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_88_8320",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_88_5442",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_35_88_1897",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_88_1943",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_88_6705",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_14_88_1573",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_88_8065",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_88_194",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_15_88_5340",
        "x": 6,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_88_5292",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_88_3987",
        "x": 6,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_30_88_2761",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_88_4681",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_88_1546",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_88_3717",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_11_88_9912",
        "x": 2,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_88_4671",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_88_5526",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_88_4920",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_88_6742",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_88_7069",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_25_88_4822",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_88_824",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_88_8661",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_88_917",
        "x": 3,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_88_9969",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_88_8465",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      }
    ]
  },
  {
    "id": "level_89",
    "number": 89,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_89_1789",
        "x": 6,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_89_3250",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_39_89_1079",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_89_1969",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_89_8173",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_31_89_2148",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_89_5229",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_89_1477",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_89_600",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_21_89_1678",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_89_3224",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_89_9316",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_89_4901",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_32_89_5857",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_33_89_7343",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_89_5919",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_34_89_3016",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_36_89_1969",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_89_5132",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_28_89_4226",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_89_6736",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_18_89_3976",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_89_4222",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_27_89_4377",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_89_3059",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_89_1246",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_89_7736",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_38_89_921",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_89_3292",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_89_6227",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_35_89_8646",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_89_3581",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_89_1398",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_89_6751",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_89_4100",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_89_8164",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_89_7214",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_89_8751",
        "x": 5,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_89_5977",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 4
      }
    ]
  },
  {
    "id": "level_90",
    "number": 90,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_32_90_1352",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_90_3258",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_3_90_6365",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_17_90_1047",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_90_8392",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_90_4958",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_90_7436",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_90_817",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_90_2252",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_90_5598",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_90_1136",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_16_90_6283",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_90_6378",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_90_1890",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_30_90_7521",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_90_741",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_21_90_8422",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_90_4675",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_8_90_3864",
        "x": 7,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_90_3794",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_90_3222",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_90_8193",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_90_7614",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_23_90_6350",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_90_281",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_90_6765",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_90_5105",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_19_90_9135",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_90_1890",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_18_90_6756",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_90_1595",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_90_2203",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_90_3011",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_91",
    "number": 91,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_1_91_4188",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_22_91_6085",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_24_91_6511",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_91_3307",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_91_1613",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_91_5616",
        "x": 5,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_91_1922",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_25_91_2989",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_15_91_9915",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_91_3931",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_91_9859",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_91_2335",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_91_5200",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_6_91_2567",
        "x": 6,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_91_3521",
        "x": 4,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_91_1352",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_91_7553",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_91_7425",
        "x": 1,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_91_5306",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_91_864",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_91_9794",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_91_6567",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_8_91_8695",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_10_91_2164",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_14_91_9255",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_91_1285",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_5_91_6638",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_91_389",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_92",
    "number": 92,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_15_92_8224",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_92_8154",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_35_92_7005",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_92_4826",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_92_3843",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_36_92_9006",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_92_8997",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_92_9086",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_92_3583",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_92_6195",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_92_1747",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_92_3556",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_92_1693",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_92_5766",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_92_1180",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_92_7545",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_92_2452",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_23_92_8596",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_92_9616",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_32_92_1354",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_92_5511",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_92_9252",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_92_4439",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_33_92_3792",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_92_8801",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_92_22",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_92_8060",
        "x": 3,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_92_5118",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_29_92_7695",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_30_92_1647",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_92_9607",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_92_6402",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_92_1829",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_92_7077",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_92_598",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_20_92_8704",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_93",
    "number": 93,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_34_93_1676",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_93_2467",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_93_2586",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_93_3918",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_93_35",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_93_9352",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_28_93_8219",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_93_3793",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_93_5945",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_8_93_9626",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_29_93_6599",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_93_8288",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_32_93_4631",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_35_93_6552",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_93_7598",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_93_6",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_93_3798",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_93_9752",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_93_9416",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_93_6912",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_93_3968",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_93_7195",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_7_93_5953",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_93_1012",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_9_93_2731",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_19_93_781",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_39_93_1660",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_93_6895",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_93_7184",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_5_93_4247",
        "x": 1,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_93_970",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_93_6051",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_93_6656",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_93_1189",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_93_961",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      }
    ]
  },
  {
    "id": "level_94",
    "number": 94,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_94_8744",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_94_685",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_94_938",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_8_94_8546",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_94_3305",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_94_9709",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_94_381",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_3_94_3084",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_94_7807",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_26_94_2572",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_94_2687",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_94_8329",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_19_94_2680",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_94_2346",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_94_7679",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_94_6949",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_94_7867",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_94_2616",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_5_94_9162",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_1_94_7303",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_6_94_22",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_94_4380",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_94_410",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_94_1085",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_13_94_973",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_94_9742",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_94_2977",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_94_9734",
        "x": 4,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_95",
    "number": 95,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_19_95_1605",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_38_95_1084",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_95_290",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_95_9645",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_34_95_7054",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_95_2758",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_95_7420",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_3_95_2610",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_37_95_9240",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_95_4227",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_95_3906",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_95_6900",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_95_7334",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_23_95_7761",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_95_8313",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_32_95_9415",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_95_5711",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_95_8872",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_36_95_3179",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_95_5436",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_95_6823",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_95_2424",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_95_9872",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_95_3142",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_95_1811",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_95_2086",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_95_1064",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_95_4693",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_95_2443",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_95_2229",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_95_8374",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_25_95_3764",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_95_4595",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_4_95_5301",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_31_95_1850",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_95_6681",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_95_7972",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_96",
    "number": 96,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_26_96_4620",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_24_96_5861",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_96_243",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_23_96_7987",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_33_96_3074",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_96_2093",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_21_96_7664",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_96_389",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_96_2759",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_96_4404",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_96_8084",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_13_96_6221",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_35_96_2385",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_96_3802",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_96_2915",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_96_6615",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_96_5456",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_8_96_4794",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_96_3292",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_38_96_5634",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_96_3870",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_96_2744",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_96_1503",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_11_96_1348",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_96_2963",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_96_8048",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_12_96_6780",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_22_96_5894",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_96_9033",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_96_3647",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_96_2151",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_96_29",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_96_4595",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_96_4565",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_97",
    "number": 97,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_14_97_127",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_97_6226",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_13_97_9712",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_97_4160",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_0_97_3589",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_16_97_879",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_20_97_3306",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_97_4244",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_97_9810",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_97_980",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_19_97_1501",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_97_4678",
        "x": 0,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_97_8526",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_21_97_7639",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_30_97_1602",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_97_3420",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_97_4851",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_28_97_4394",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_97_3923",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_97_3138",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_97_1340",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_97_1523",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_97_162",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_97_8048",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_97_4673",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_97_5687",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_97_8313",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_97_4542",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_97_6639",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_97_2735",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_98",
    "number": 98,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_98_128",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_98_9374",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_33_98_7582",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_34_98_1573",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_98_7595",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_38_98_9082",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_98_5215",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_29_98_2689",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_98_497",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_98_3961",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_98_5874",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_98_5357",
        "x": 2,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_98_1185",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_98_2070",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_98_7255",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_18_98_243",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_23_98_3841",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_98_5344",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_98_663",
        "x": 6,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_26_98_1459",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_98_7878",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_98_8585",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_98_5871",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_20_98_8682",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_98_4281",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_10_98_3659",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_98_3629",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_98_8060",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_98_4441",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_32_98_9609",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_98_555",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_98_7423",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_98_763",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_98_1525",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_6_98_220",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_98_8639",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 3
      }
    ]
  },
  {
    "id": "level_99",
    "number": 99,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_32_99_1427",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_34_99_6926",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_99_5406",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_99_246",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_99_5480",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_22_99_7355",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_99_2693",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_99_161",
        "x": 7,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_99_3836",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_99_6424",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_99_5860",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_99_2330",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_99_7474",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_99_7957",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_99_3757",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_16_99_5081",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_99_5962",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_99_9348",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_30_99_6155",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_99_8018",
        "x": 0,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_99_2578",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_99_2813",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_99_3902",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_24_99_6869",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_15_99_1261",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_99_2676",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_33_99_2947",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_99_2095",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_99_6672",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_99_7534",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_99_3984",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_99_4362",
        "x": 6,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_99_7668",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_99_1771",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_29_99_159",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_35_99_4579",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_100",
    "number": 100,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_17_100_1904",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_5_100_6113",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_15_100_4644",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_100_6526",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_22_100_3409",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_100_9774",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_100_619",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_100_4534",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_100_2787",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_100_3308",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_14_100_198",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_100_7445",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_100_9938",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_100_7013",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_28_100_340",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_100_1145",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_33_100_8967",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_100_6176",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_100_5095",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_10_100_6015",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_25_100_7276",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_37_100_6431",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_100_4454",
        "x": 1,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_100_4525",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_100_3078",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_100_3031",
        "x": 0,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_100_3875",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_100_3539",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_100_5388",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_24_100_7099",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_100_5541",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_100_2846",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_39_100_8109",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_100_3341",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_100_9703",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  }
];
