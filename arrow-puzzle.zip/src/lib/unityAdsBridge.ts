/**
 * Unity Ads Bridge for Native Android & Web Integration
 * Unity Game ID: 6094029
 * Interstitial Placement: Interstitial_Android
 * Rewarded Placement: Rewarded_Android
 */

declare global {
  interface Window {
    // Injected by Android WebView natively
    AndroidUnityAds?: {
      initialize(gameId: string, testMode: boolean): void;
      showInterstitial(placementId: string): void;
      showRewarded(placementId: string): void;
      isReady(placementId: string): boolean;
    };
    // Callbacks triggered by Native Android code to update Web state
    onUnityAdFinished?: (placementId: string, result: 'COMPLETED' | 'SKIPPED' | 'FAILED') => void;
  }
}

export const AdConfig = {
  GAME_ID: '6094029',
  INTERSTITIAL_PLACEMENT: 'Interstitial_Android',
  REWARDED_PLACEMENT: 'Rewarded_Android',
  DAILY_SPIN_AD_LIMIT: 20,
};

// State to track ad readiness
let isInitialized = false;
let currentActiveAd: HTMLDivElement | null = null;

export const UnityAds = {
  /**
   * Initializes the Unity Ads SDK via native bridge and Web Player.
   * @param testMode Set to false for REAL/PRODUCTION ads.
   */
  initialize: (testMode: boolean = false) => {
    isInitialized = true;
    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      try {
        window.AndroidUnityAds.initialize(AdConfig.GAME_ID, testMode);
        console.log('[UnityAds] Native Android Bridge initialized with Game ID:', AdConfig.GAME_ID, 'testMode:', testMode);
      } catch (err) {
        console.warn('[UnityAds] Error initializing native bridge:', err);
      }
    } else {
      console.log('[UnityAds] Web Unity Ads Engine ready with Game ID:', AdConfig.GAME_ID);
    }
  },

  /**
   * Shows an Interstitial Ad and returns a Promise resolving when the ad is closed.
   */
  showInterstitial: (placementId: string = AdConfig.INTERSTITIAL_PLACEMENT): Promise<boolean> => {
    return new Promise((resolve) => {
      // 1. If running inside Native Android APK with AndroidUnityAds bridge:
      if (typeof window !== 'undefined' && window.AndroidUnityAds) {
        let finished = false;

        window.onUnityAdFinished = (finishedPlacement, result) => {
          if (finishedPlacement === placementId && !finished) {
            finished = true;
            window.onUnityAdFinished = undefined;
            console.log('[UnityAds Native] Interstitial ad completed with result:', result);
            resolve(result === 'COMPLETED' || result === 'SKIPPED');
          }
        };

        try {
          console.log('[UnityAds Native] Invoking AndroidUnityAds.showInterstitial:', placementId);
          window.AndroidUnityAds.showInterstitial(placementId);
          return;
        } catch (err) {
          console.warn('[UnityAds Native] Error invoking showInterstitial:', err);
          window.onUnityAdFinished = undefined;
        }
      }

      // 2. Web Preview Environment (Browser): Real Unity mobile SDK runs in Android APK
      showWebUnityAd(placementId, 'INTERSTITIAL', resolve);
    });
  },

  /**
   * Shows a Rewarded Ad and returns a Promise that resolves to true if completed.
   */
  showRewarded: (placementId: string = AdConfig.REWARDED_PLACEMENT): Promise<boolean> => {
    return new Promise((resolve) => {
      // 1. If running inside Native Android APK with AndroidUnityAds bridge:
      if (typeof window !== 'undefined' && window.AndroidUnityAds) {
        let finished = false;

        window.onUnityAdFinished = (finishedPlacement, result) => {
          if (finishedPlacement === placementId && !finished) {
            finished = true;
            window.onUnityAdFinished = undefined;
            console.log('[UnityAds Native] Rewarded ad completed with result:', result);
            resolve(result === 'COMPLETED');
          }
        };

        try {
          console.log('[UnityAds Native] Invoking AndroidUnityAds.showRewarded:', placementId);
          window.AndroidUnityAds.showRewarded(placementId);
          return;
        } catch (err) {
          console.warn('[UnityAds Native] Error invoking showRewarded:', err);
          window.onUnityAdFinished = undefined;
        }
      }

      // 2. Web Preview Environment (Browser): Real Unity mobile SDK runs in Android APK
      showWebUnityAd(placementId, 'REWARDED', resolve);
    });
  },

  /**
   * Checks if an ad placement is ready.
   */
  isReady: (placementId: string): boolean => {
    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      try {
        return window.AndroidUnityAds.isReady(placementId);
      } catch {
        return true;
      }
    }
    return true;
  }
};

/**
 * Unity Ads Preview Tester for Browser Environments
 * Clearly explains that real Unity video ads run via the native Android APK
 * and allows instant verification of in-game reward callbacks during web development.
 */
function showWebUnityAd(
  placementId: string, 
  adType: 'INTERSTITIAL' | 'REWARDED', 
  resolve: (success: boolean) => void
) {
  if (typeof document === 'undefined') {
    resolve(true);
    return;
  }

  // Remove any previous active ad
  if (currentActiveAd) {
    try { document.body.removeChild(currentActiveAd); } catch {}
    currentActiveAd = null;
  }

  const isRewarded = adType === 'REWARDED';
  let countdown = isRewarded ? 4 : 2;
  let hasCompleted = false;

  // Create full-screen modal container
  const adContainer = document.createElement('div');
  adContainer.id = 'unity-ads-overlay';
  adContainer.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(13, 17, 23, 0.95);
    z-index: 999999;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #ffffff;
    user-select: none;
    padding: 20px;
    box-sizing: border-box;
    backdrop-filter: blur(8px);
    animation: unityFadeIn 0.2s ease-out forwards;
  `;

  // Inject animation keyframes if not existing
  if (!document.getElementById('unity-ad-styles')) {
    const styleTag = document.createElement('style');
    styleTag.id = 'unity-ad-styles';
    styleTag.textContent = `
      @keyframes unityFadeIn { from { opacity: 0; transform: scale(0.98); } to { opacity: 1; transform: scale(1); } }
      .unity-btn:active { transform: scale(0.97); }
    `;
    document.head.appendChild(styleTag);
  }

  // Modal Card
  const card = document.createElement('div');
  card.style.cssText = `
    background: #161b22;
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 20px;
    width: 100%;
    max-width: 440px;
    padding: 24px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
    display: flex;
    flex-direction: column;
    gap: 18px;
    box-sizing: border-box;
  `;

  // Header
  const header = document.createElement('div');
  header.style.cssText = 'display: flex; align-items: center; justify-content: space-between;';
  header.innerHTML = `
    <div style="display: flex; align-items: center; gap: 10px;">
      <div style="width: 38px; height: 38px; background: #ffffff; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000000">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
        </svg>
      </div>
      <div>
        <div style="font-size: 17px; font-weight: 800; color: #ffffff; letter-spacing: -0.2px;">Unity Ads</div>
        <div style="font-size: 11px; font-weight: 600; color: #38bdf8; text-transform: uppercase; letter-spacing: 0.5px;">Web Preview Mode</div>
      </div>
    </div>
    <div id="unity-timer-badge" style="background: rgba(34, 197, 94, 0.15); border: 1px solid rgba(34, 197, 94, 0.3); color: #4ade80; font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 14px;">
      ${countdown}s
    </div>
  `;

  // Details Info Card
  const infoBlock = document.createElement('div');
  infoBlock.style.cssText = `
    background: #0d1117;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 14px;
    padding: 14px 16px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    font-size: 13px;
  `;
  infoBlock.innerHTML = `
    <div style="display: flex; justify-content: space-between; color: #94a3b8;">
      <span>Unity Game ID:</span>
      <span style="color: #f8fafc; font-family: monospace; font-weight: 600;">${AdConfig.GAME_ID}</span>
    </div>
    <div style="display: flex; justify-content: space-between; color: #94a3b8;">
      <span>Ad Placement:</span>
      <span style="color: #38bdf8; font-family: monospace; font-weight: 600;">${placementId}</span>
    </div>
    <div style="display: flex; justify-content: space-between; color: #94a3b8;">
      <span>Mode:</span>
      <span style="color: #4ade80; font-weight: 700;">Production (Real Ads)</span>
    </div>
  `;

  // Explanation
  const note = document.createElement('div');
  note.style.cssText = 'font-size: 12px; line-height: 1.5; color: #94a3b8; background: rgba(56, 189, 248, 0.08); border-left: 3px solid #38bdf8; padding: 10px 12px; border-radius: 6px;';
  note.innerHTML = `
    <strong style="color: #e2e8f0;">Why this appears in Preview:</strong><br/>
    Unity Ads does not provide a web browser SDK. Real video advertisements stream natively on Android devices once built as an APK.
  `;

  // Actions
  const actions = document.createElement('div');
  actions.style.cssText = 'display: flex; gap: 10px; margin-top: 4px;';

  const skipBtn = document.createElement('button');
  skipBtn.className = 'unity-btn';
  skipBtn.style.cssText = `
    flex: 1;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: #cbd5e1;
    padding: 12px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 13px;
    cursor: pointer;
  `;
  skipBtn.textContent = 'Skip Ad';

  const claimBtn = document.createElement('button');
  claimBtn.id = 'unity-claim-btn';
  claimBtn.className = 'unity-btn';
  claimBtn.style.cssText = `
    flex: 2;
    background: #3b82f6;
    border: none;
    color: #ffffff;
    padding: 12px;
    border-radius: 12px;
    font-weight: 700;
    font-size: 13px;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
  `;
  claimBtn.textContent = isRewarded ? `Watching (${countdown}s)...` : `Closing (${countdown}s)...`;

  actions.appendChild(skipBtn);
  actions.appendChild(claimBtn);

  card.appendChild(header);
  card.appendChild(infoBlock);
  card.appendChild(note);
  card.appendChild(actions);
  adContainer.appendChild(card);

  document.body.appendChild(adContainer);
  currentActiveAd = adContainer;

  function closeAd(wasCompleted: boolean) {
    if (adContainer.parentNode) {
      adContainer.parentNode.removeChild(adContainer);
    }
    currentActiveAd = null;

    if (window.onUnityAdFinished) {
      window.onUnityAdFinished(placementId, wasCompleted ? 'COMPLETED' : 'SKIPPED');
    }

    resolve(wasCompleted);
  }

  // Countdown timer
  const interval = setInterval(() => {
    countdown--;
    const timerBadge = document.getElementById('unity-timer-badge');
    const claimBtnEl = document.getElementById('unity-claim-btn');

    if (countdown > 0) {
      if (timerBadge) timerBadge.textContent = `${countdown}s`;
      if (claimBtnEl) claimBtnEl.textContent = isRewarded ? `Watching (${countdown}s)...` : `Closing (${countdown}s)...`;
    } else {
      clearInterval(interval);
      hasCompleted = true;
      if (timerBadge) {
        timerBadge.textContent = '✓ Ready';
        timerBadge.style.background = '#22c55e';
        timerBadge.style.color = '#ffffff';
      }
      if (claimBtnEl) {
        claimBtnEl.textContent = isRewarded ? '✓ Claim Reward' : '✓ Continue';
        claimBtnEl.style.background = '#22c55e';
      }
      // Auto-finish after 0.8s
      setTimeout(() => {
        if (currentActiveAd === adContainer) {
          closeAd(true);
        }
      }, 800);
    }
  }, 1000);

  skipBtn.onclick = () => {
    clearInterval(interval);
    closeAd(false);
  };

  claimBtn.onclick = () => {
    clearInterval(interval);
    closeAd(true);
  };
}
