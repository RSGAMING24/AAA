import { useState, useEffect } from 'react';
import { Home } from './views/Home';
import { LevelSelect } from './views/LevelSelect';
import { Game } from './views/Game';
import { Admin } from './views/Admin';
import { DailyReward } from './views/DailyReward';
import { Shop } from './views/Shop';
import { SpinWheel } from './views/SpinWheel';
import { useLocalStorage } from './hooks/useLocalStorage';
import { defaultLevels } from './lib/defaultLevels';
import { PlayerProgress, LevelData } from './types';
import { UnityAds } from './lib/unityAdsBridge';

export type ViewState = 'HOME' | 'LEVEL_SELECT' | 'GAME' | 'ADMIN' | 'DAILY_REWARD' | 'SHOP' | 'SPIN';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('HOME');
  const [activeLevel, setActiveLevel] = useState<number>(1);
  const [progress, setProgress] = useLocalStorage<PlayerProgress>('arrow_puzzle_progress', {
    currentLevel: 1,
    unlockedLevels: [1],
    completedLevels: {},
    coins: 0,
    dailyRewards: {
      lastClaimDate: null,
      currentDay: 1
    },
    settings: {
      sound: true,
      vibration: true,
      theme: 'Light'
    }
  });
  const [levels, setLevels] = useLocalStorage<LevelData[]>('arrow_puzzle_levels', defaultLevels);

  useEffect(() => {
    if (!levels || levels.length === 0) {
      setLevels(defaultLevels);
    }
  }, [levels, setLevels]);

  useEffect(() => {
    const path = window.location.pathname;
    if (path === '/admin' || path === '/admin-panel') {
      setCurrentView('ADMIN');
    }
    UnityAds.initialize(false);
  }, []);

  useEffect(() => {
    setProgress(prev => {
      let updated = { ...prev };
      if (!prev.settings) {
        updated.settings = {
          sound: true,
          vibration: true,
          theme: 'System'
        };
      }
      if (typeof prev.coins === 'undefined') {
        updated.coins = 0;
      }
      if (!prev.dailyRewards) {
        updated.dailyRewards = {
          lastClaimDate: null,
          currentDay: 1
        };
      }
      if (!prev.inventory) {
        updated.inventory = {
          ownedColors: ['#574C43'],
          ownedThemes: ['default'],
          ownedAnimations: [],
          globalHints: 0,
          globalHearts: 0
        };
      } else if (updated.inventory && !updated.inventory.ownedAnimations) {
        updated.inventory = {
          ...updated.inventory,
          ownedAnimations: []
        };
      }
      
      if (!prev.equipped) {
        updated.equipped = {
          color: '#574C43',
          theme: 'default',
          animation: null
        };
      }
      return updated;
    });
  }, []);

  useEffect(() => {
    const theme = progress.settings?.theme || 'System';
    const isDark = theme === 'Dark' || (theme === 'System' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [progress.settings?.theme]);

  const navigateTo = (view: ViewState, levelNum?: number) => {
    if (levelNum !== undefined) {
      setActiveLevel(levelNum);
    }
    setCurrentView(view);
    
    if (view === 'ADMIN') {
      window.history.pushState({}, '', '/admin');
    } else if (window.location.pathname !== '/') {
      window.history.pushState({}, '', '/');
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#FDFBF7] text-slate-800 font-sans selection:bg-amber-200 overflow-x-hidden">
      {currentView === 'HOME' && <Home onNavigate={navigateTo} progress={progress} setProgress={setProgress} levels={levels} />}
      {currentView === 'DAILY_REWARD' && <DailyReward onNavigate={navigateTo} progress={progress} setProgress={setProgress} />}
      {currentView === 'SHOP' && <Shop onNavigate={navigateTo} progress={progress} setProgress={setProgress} />}
      {currentView === 'SPIN' && <SpinWheel onNavigate={navigateTo} progress={progress} setProgress={setProgress} />}
      {currentView === 'LEVEL_SELECT' && <LevelSelect onNavigate={navigateTo} progress={progress} levels={levels} />}
      {currentView === 'GAME' && <Game onNavigate={navigateTo} levelNumber={activeLevel} progress={progress} setProgress={setProgress} levels={levels} />}
      {currentView === 'ADMIN' && <Admin levels={levels} setLevels={setLevels} onNavigate={navigateTo} />}
    </div>
  );
}
