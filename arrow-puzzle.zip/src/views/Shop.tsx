import { useState } from 'react';
import { ViewState } from '../App';
import { PlayerProgress } from '../types';
import { ArrowLeft, Palette, Image as ImageIcon, Sparkles, Zap, Heart, Lightbulb, MonitorPlay } from 'lucide-react';
import { cn, playSound, playVibration } from '../lib/utils';
import { motion } from 'motion/react';
import { ArrowSvg } from '../components/ArrowSvg';
import { UnityAds } from '../lib/unityAdsBridge';

interface ShopProps {
  onNavigate: (v: ViewState, level?: number) => void;
  progress: PlayerProgress;
  setProgress: React.Dispatch<React.SetStateAction<PlayerProgress>>;
}

const basicColors = [
  { id: '#ef4444', name: 'Ruby Red', price: 100 },
  { id: '#3b82f6', name: 'Ocean Blue', price: 100 },
  { id: '#10b981', name: 'Emerald', price: 100 },
  { id: '#8b5cf6', name: 'Amethyst', price: 100 },
  { id: '#f97316', name: 'Sunset', price: 100 },
];

const themes = [
  { id: 'default', name: 'Default', price: 0 },
  { id: 'midnight', name: 'Midnight Blue', price: 1000 },
  { id: 'sakura', name: 'Sakura Pink', price: 1000 },
  { id: 'forest', name: 'Forest Zen', price: 1000 },
  { id: 'sunset', name: 'Golden Sunset', price: 1000 },
];

const animations = [
  { id: 'SPIN', name: 'Cyclone Spin', price: 1500 },
  { id: 'ZOOM_OUT', name: 'Vanish', price: 1500 },
  { id: 'FADE_UP', name: 'Ascend', price: 1500 },
];

export function Shop({ onNavigate, progress, setProgress }: ShopProps) {
  const [activeTab, setActiveTab] = useState<'Colors' | 'Themes' | 'Animations' | 'Boosters'>('Colors');
  const [customColor, setCustomColor] = useState('#D946EF');
  const [adLoading, setAdLoading] = useState(false);

  const coins = progress.coins || 0;
  const inventory = progress.inventory || {
    ownedColors: ['#574C43'],
    ownedThemes: ['default'],
    ownedAnimations: [],
    globalHints: 0,
    globalHearts: 0
  };
  const equipped = progress.equipped || {
    color: '#574C43',
    theme: 'default',
    animation: null
  };

  const handlePurchase = (price: number, patchFn: (prev: typeof progress) => Partial<typeof progress>) => {
    if (coins >= price) {
      playSound('success', progress.settings?.sound ?? true);
      playVibration(50);
      setProgress(prev => ({
        ...prev,
        coins: prev.coins - price,
        ...patchFn(prev)
      }));
    } else {
      playSound('error', progress.settings?.sound ?? true);
      playVibration([50, 50, 50]);
    }
  };

  const buyColor = (color: string, price: number) => {
    if (inventory.ownedColors.includes(color)) {
      setProgress(prev => ({ ...prev, equipped: { ...prev.equipped!, color } }));
      return;
    }
    handlePurchase(price, (prev) => ({
      inventory: { ...prev.inventory!, ownedColors: [...prev.inventory!.ownedColors, color] },
      equipped: { ...prev.equipped!, color }
    }));
  };

  const buyTheme = (themeId: string, price: number) => {
    if (inventory.ownedThemes.includes(themeId)) {
      setProgress(prev => ({ ...prev, equipped: { ...prev.equipped!, theme: themeId } }));
      return;
    }
    handlePurchase(price, (prev) => ({
      inventory: { ...prev.inventory!, ownedThemes: [...prev.inventory!.ownedThemes, themeId] },
      equipped: { ...prev.equipped!, theme: themeId }
    }));
  };

  const buyAnimation = (animId: string, price: number) => {
    if (inventory.ownedAnimations?.includes(animId)) {
      setProgress(prev => ({ ...prev, equipped: { ...prev.equipped!, animation: animId } }));
      return;
    }
    handlePurchase(price, (prev) => ({
      inventory: { ...prev.inventory!, ownedAnimations: [...(prev.inventory!.ownedAnimations || []), animId] },
      equipped: { ...prev.equipped!, animation: animId }
    }));
  };

  const unequipAnimation = () => {
    setProgress(prev => ({ ...prev, equipped: { ...prev.equipped!, animation: null } }));
  };

  const buyHint = () => {
    handlePurchase(200, (prev) => ({
      inventory: { ...prev.inventory!, globalHints: prev.inventory!.globalHints + 1 }
    }));
  };

  const buyHeart = () => {
    handlePurchase(300, (prev) => ({
      inventory: { ...prev.inventory!, globalHearts: prev.inventory!.globalHearts + 1 }
    }));
  };

  const handleAdPurchase = async (type: 'hint' | 'heart') => {
    if (adLoading) return;
    setAdLoading(true);
    const success = await UnityAds.showRewarded();
    setAdLoading(false);
    
    if (success) {
      playSound('success', progress.settings?.sound ?? true);
      playVibration(50);
      setProgress(prev => ({
        ...prev,
        inventory: { 
          ...prev.inventory!, 
          globalHints: prev.inventory!.globalHints + (type === 'hint' ? 1 : 0),
          globalHearts: prev.inventory!.globalHearts + (type === 'heart' ? 1 : 0)
        }
      }));
    }
  };

  const handleAdUnlockItem = async (type: 'color' | 'theme' | 'animation', id: string) => {
    if (adLoading) return;
    setAdLoading(true);
    const success = await UnityAds.showRewarded();
    setAdLoading(false);
    
    if (success) {
      playSound('success', progress.settings?.sound ?? true);
      playVibration(50);
      setProgress(prev => {
        const inv = prev.inventory || { ownedColors: ['#574C43'], ownedThemes: ['default'], ownedAnimations: [], globalHints: 0, globalHearts: 0 };
        const eq = prev.equipped || { color: '#574C43', theme: 'default', animation: null };
        if (type === 'color') {
          return { ...prev, inventory: { ...inv, ownedColors: [...inv.ownedColors, id] }, equipped: { ...eq, color: id } };
        } else if (type === 'theme') {
          return { ...prev, inventory: { ...inv, ownedThemes: [...inv.ownedThemes, id] }, equipped: { ...eq, theme: id } };
        } else {
          return { ...prev, inventory: { ...inv, ownedAnimations: [...(inv.ownedAnimations || []), id] }, equipped: { ...eq, animation: id } };
        }
      });
    }
  };

  return (
    <div className="flex flex-col min-h-[100dvh] p-4 max-w-md mx-auto bg-[#FDFBF7] dark:bg-slate-950 transition-colors duration-300">
      <div className="flex items-center justify-between mb-6 pt-4 sticky top-0 bg-[#FDFBF7]/90 dark:bg-slate-950/90 backdrop-blur-md z-20 pb-4 border-b border-slate-200 dark:border-slate-800">
        <button 
          onClick={() => onNavigate('HOME')}
          className="p-3 hover:bg-slate-200/50 dark:hover:bg-slate-800/50 rounded-full transition-colors active:scale-95"
        >
          <ArrowLeft size={24} className="text-slate-800 dark:text-slate-200" />
        </button>
        <h1 className="font-bold text-xl text-slate-900 dark:text-slate-100 tracking-widest pl-6">SHOP</h1>
        <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-900/20 px-3 py-1.5 rounded-full border border-amber-200/50 dark:border-amber-700/50">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" className="text-amber-500">
            <circle cx="12" cy="12" r="10" />
            <text x="12" y="16.5" fontSize="12" fill="#FFF" textAnchor="middle" fontWeight="bold">C</text>
          </svg>
          <span className="text-amber-600 dark:text-amber-400 font-bold text-sm">{coins}</span>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-4 custom-scrollbar">
        {(['Colors', 'Themes', 'Animations', 'Boosters'] as const).map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "px-4 py-2 rounded-full font-bold text-sm whitespace-nowrap transition-all",
              activeTab === tab 
                ? "bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-md" 
                : "bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
            )}
          >
            {tab === 'Colors' && <Palette size={16} className="inline mr-2 -mt-0.5" />}
            {tab === 'Themes' && <ImageIcon size={16} className="inline mr-2 -mt-0.5" />}
            {tab === 'Animations' && <Sparkles size={16} className="inline mr-2 -mt-0.5" />}
            {tab === 'Boosters' && <Zap size={16} className="inline mr-2 -mt-0.5" />}
            {tab}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto pb-12 custom-scrollbar flex flex-col gap-4">
        
        {/* COLORS TAB */}
        {activeTab === 'Colors' && (
          <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="flex flex-col gap-6">
            
            {/* Custom Color */}
            <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col gap-4">
              <h3 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <Palette size={18} className="text-fuchsia-500" /> Custom Color Creator
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Create your own unique arrow color and stand out!</p>
              
              <div className="flex items-center gap-4">
                <div className="relative w-16 h-16 rounded-xl overflow-hidden shadow-inner border-2 border-slate-200 dark:border-slate-700 flex-shrink-0 cursor-pointer">
                  <input 
                    type="color" 
                    value={customColor}
                    onChange={e => setCustomColor(e.target.value)}
                    className="absolute inset-0 w-24 h-24 -top-2 -left-2 cursor-pointer"
                  />
                </div>
                
                <div className="flex-1 h-16 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-center relative border border-slate-100 dark:border-slate-700">
                   <ArrowSvg length={1} direction="RIGHT" cellSize={60} strokeColor={customColor} />
                </div>
              </div>

              <div className="w-full flex gap-2 mt-2">
                <button 
                  onClick={() => buyColor(customColor, 500)}
                  disabled={adLoading}
                  className="flex-1 py-3 bg-fuchsia-100 dark:bg-fuchsia-900/30 text-fuchsia-700 dark:text-fuchsia-400 font-bold rounded-xl active:scale-95 transition-all flex justify-center items-center gap-2 disabled:opacity-70"
                >
                  {inventory.ownedColors.includes(customColor) ? (
                    equipped.color === customColor ? 'EQUIPPED' : 'EQUIP'
                  ) : (
                    <>BUY 500 C</>
                  )}
                </button>
                {!inventory.ownedColors.includes(customColor) && (
                  <button 
                    onClick={() => handleAdUnlockItem('color', customColor)}
                    disabled={adLoading}
                    className="flex-1 py-3 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 font-bold rounded-xl active:scale-95 transition-all flex justify-center items-center gap-1 border border-indigo-200 dark:border-indigo-800 disabled:opacity-70 disabled:cursor-wait"
                  >
                    <MonitorPlay size={16} /> {adLoading ? 'WAIT' : 'FREE AD'}
                  </button>
                )}
              </div>
            </div>

            <h3 className="font-bold text-slate-400 text-xs tracking-widest uppercase px-2">Basic Colors</h3>
            <div className="grid grid-cols-2 gap-3">
              {/* Default Color manually rendered */}
              <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col items-center gap-3 relative overflow-hidden">
                <div className="w-12 h-12 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-1">
                  <div className="w-6 h-6 rounded-full" style={{ backgroundColor: '#574C43' }}></div>
                </div>
                <span className="font-bold text-sm text-slate-700 dark:text-slate-300">Classic</span>
                <button 
                  onClick={() => buyColor('#574C43', 0)}
                  className={cn("w-full py-2 rounded-lg text-xs font-bold transition-all", equipped.color === '#574C43' ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400" : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300")}
                >
                  {equipped.color === '#574C43' ? 'EQUIPPED' : 'EQUIP'}
                </button>
              </div>

              {basicColors.map(color => {
                const isOwned = inventory.ownedColors.includes(color.id);
                const isEquipped = equipped.color === color.id;
                
                return (
                  <div key={color.id} className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col items-center gap-3 relative overflow-hidden">
                    <div className="w-12 h-12 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-1">
                      <div className="w-6 h-6 rounded-full shadow-inner" style={{ backgroundColor: color.id }}></div>
                    </div>
                    <span className="font-bold text-sm text-slate-700 dark:text-slate-300">{color.name}</span>
                    {!isOwned ? (
                      <div className="w-full flex gap-1 mt-1">
                        <button 
                          onClick={() => buyColor(color.id, color.price)}
                          disabled={adLoading}
                          className="flex-1 py-2 rounded-lg text-xs font-bold transition-all flex justify-center items-center bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 hover:bg-amber-200 dark:hover:bg-amber-800/40 disabled:opacity-70"
                        >
                          {color.price} C
                        </button>
                        <button 
                          onClick={() => handleAdUnlockItem('color', color.id)}
                          disabled={adLoading}
                          className="flex-1 py-2 rounded-lg text-xs font-bold transition-all flex justify-center items-center bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 gap-1 disabled:opacity-70 disabled:cursor-wait"
                        >
                          <MonitorPlay size={12} /> AD
                        </button>
                      </div>
                    ) : (
                      <button 
                        onClick={() => buyColor(color.id, color.price)}
                        disabled={adLoading}
                        className={cn("w-full py-2 rounded-lg text-xs font-bold transition-all flex justify-center items-center mt-1 disabled:opacity-70", 
                          isEquipped ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400" : 
                          "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                        )}
                      >
                        {isEquipped ? 'EQUIPPED' : 'EQUIP'}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* THEMES TAB */}
        {activeTab === 'Themes' && (
          <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="flex flex-col gap-4">
            {themes.map(theme => {
              const isOwned = inventory.ownedThemes.includes(theme.id);
              const isEquipped = equipped.theme === theme.id;
              
              let previewBg = "bg-slate-100";
              if (theme.id === 'midnight') previewBg = "bg-blue-900";
              if (theme.id === 'sakura') previewBg = "bg-pink-100";
              if (theme.id === 'forest') previewBg = "bg-emerald-100";
              if (theme.id === 'sunset') previewBg = "bg-orange-100";

              return (
                <div key={theme.id} className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                  <div className={cn("w-16 h-16 rounded-2xl flex-shrink-0 shadow-inner border border-slate-200 dark:border-slate-700", previewBg)}></div>
                  <div className="flex-1">
                    <h3 className="font-bold text-slate-800 dark:text-slate-200 mb-1">{theme.name}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{isOwned ? 'Permanent unlock' : '1000 Coins'}</p>
                  </div>

                  <div className="flex flex-col gap-1 flex-shrink-0 w-28">
                    {!isOwned ? (
                      <>
                        <button 
                          onClick={() => buyTheme(theme.id, theme.price)}
                          disabled={adLoading}
                          className="w-full px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 disabled:opacity-70"
                        >
                          {theme.price} C
                        </button>
                        <button 
                          onClick={() => handleAdUnlockItem('theme', theme.id)}
                          disabled={adLoading}
                          className="w-full px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center gap-1 disabled:opacity-70 disabled:cursor-wait"
                        >
                          <MonitorPlay size={12} /> {adLoading ? 'WAIT' : 'AD'}
                        </button>
                      </>
                    ) : (
                      <button 
                        onClick={() => buyTheme(theme.id, theme.price)}
                        disabled={adLoading}
                        className={cn("w-full px-4 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap disabled:opacity-70", 
                          isEquipped ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400" : 
                          "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                        )}
                      >
                        {isEquipped ? 'EQUIPPED' : 'EQUIP'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* ANIMATIONS TAB */}
        {activeTab === 'Animations' && (
          <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="flex flex-col gap-4">
             <div className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
                <div>
                   <h3 className="font-bold text-slate-800 dark:text-slate-200">Default Exit</h3>
                   <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Included</p>
                </div>
                <button 
                   onClick={unequipAnimation}
                   className={cn("px-4 py-2.5 rounded-xl text-sm font-bold transition-all", equipped.animation === null ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400" : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300")}
                >
                  {equipped.animation === null ? 'EQUIPPED' : 'EQUIP'}
                </button>
             </div>

            {animations.map(anim => {
              const isOwned = inventory.ownedAnimations?.includes(anim.id);
              const isEquipped = equipped.animation === anim.id;
              
              return (
                <div key={anim.id} className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="font-bold text-slate-800 dark:text-slate-200">{anim.name}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">{isOwned ? 'Permanent unlock' : `${anim.price} Coins`}</p>
                  </div>
                  
                  <div className="flex flex-col gap-1 flex-shrink-0 w-28">
                    {!isOwned ? (
                      <>
                        <button 
                          onClick={() => buyAnimation(anim.id, anim.price)}
                          disabled={adLoading}
                          className="w-full px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 disabled:opacity-70"
                        >
                          {anim.price} C
                        </button>
                        <button 
                          onClick={() => handleAdUnlockItem('animation', anim.id)}
                          disabled={adLoading}
                          className="w-full px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center gap-1 disabled:opacity-70 disabled:cursor-wait"
                        >
                          <MonitorPlay size={12} /> {adLoading ? 'WAIT' : 'AD'}
                        </button>
                      </>
                    ) : (
                      <button 
                        onClick={() => buyAnimation(anim.id, anim.price)}
                        disabled={adLoading}
                        className={cn("w-full px-4 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap disabled:opacity-70", 
                          isEquipped ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400" : 
                          "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                        )}
                      >
                        {isEquipped ? 'EQUIPPED' : 'EQUIP'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* BOOSTERS TAB */}
        {activeTab === 'Boosters' && (
          <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="grid grid-cols-2 gap-3">
            
            <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center text-center gap-4">
              <div className="w-14 h-14 bg-amber-100 dark:bg-amber-900/30 text-amber-500 rounded-2xl flex items-center justify-center">
                <Lightbulb size={28} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 dark:text-slate-200">Global Hint</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">Use when stuck!</p>
                <div className="mt-2 text-sm font-bold text-slate-700 dark:text-slate-300">Owned: {inventory.globalHints}</div>
              </div>
              <div className="w-full flex flex-col gap-2 mt-auto">
                <button 
                  onClick={buyHint}
                  disabled={adLoading}
                  className="w-full py-2.5 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 font-bold rounded-xl active:scale-95 transition-all text-sm disabled:opacity-70"
                >
                  BUY FOR 200 C
                </button>
                <button 
                  onClick={() => handleAdPurchase('hint')}
                  disabled={adLoading}
                  className="w-full py-2.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 font-bold rounded-xl active:scale-95 transition-all text-sm flex items-center justify-center gap-2 border border-indigo-200 dark:border-indigo-800 disabled:opacity-70 disabled:cursor-wait"
                >
                  <MonitorPlay size={16} /> {adLoading ? "LOADING" : "FREE AD"}
                </button>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center text-center gap-4">
              <div className="w-14 h-14 bg-rose-100 dark:bg-rose-900/30 text-rose-500 rounded-2xl flex items-center justify-center">
                <Heart size={28} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 dark:text-slate-200">Extra Heart</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">Revive on fail!</p>
                <div className="mt-2 text-sm font-bold text-slate-700 dark:text-slate-300">Owned: {inventory.globalHearts}</div>
              </div>
              <div className="w-full flex flex-col gap-2 mt-auto">
                <button 
                  onClick={buyHeart}
                  disabled={adLoading}
                  className="w-full py-2.5 bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400 font-bold rounded-xl active:scale-95 transition-all text-sm disabled:opacity-70"
                >
                  BUY FOR 300 C
                </button>
                <button 
                  onClick={() => handleAdPurchase('heart')}
                  disabled={adLoading}
                  className="w-full py-2.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 font-bold rounded-xl active:scale-95 transition-all text-sm flex items-center justify-center gap-2 border border-indigo-200 dark:border-indigo-800 disabled:opacity-70 disabled:cursor-wait"
                >
                  <MonitorPlay size={16} /> {adLoading ? "LOADING" : "FREE AD"}
                </button>
              </div>
            </div>

          </motion.div>
        )}

      </div>
    </div>
  );
}
