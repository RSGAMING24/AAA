import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ViewState } from '../App';
import { PlayerProgress } from '../types';
import { ChevronLeft, Coins, MonitorPlay } from 'lucide-react';
import { cn, playSound, playVibration, playSpinSound } from '../lib/utils';
import { UnityAds, AdConfig } from '../lib/unityAdsBridge';

interface SpinWheelProps {
  onNavigate: (v: ViewState) => void;
  progress: PlayerProgress;
  setProgress: React.Dispatch<React.SetStateAction<PlayerProgress>>;
}

const SEGMENTS = [2, 10, 100, 3, 9, 200, 5];
const SEGMENT_ANGLE = 360 / SEGMENTS.length;

export function SpinWheel({ onNavigate, progress, setProgress }: SpinWheelProps) {
  const [rotation, setRotation] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rewardToCollect, setRewardToCollect] = useState<number | null>(null);
  const spinAudioRef = React.useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    try {
      spinAudioRef.current = new Audio('/spin-wheel.mp3');
      spinAudioRef.current.loop = true;
    } catch {
      // Audio optional
    }
    return () => {
      if (spinAudioRef.current) {
        spinAudioRef.current.pause();
        spinAudioRef.current = null;
      }
    };
  }, []);

  const getTodayString = () => new Date().toISOString().split('T')[0];
  const today = getTodayString();
  const spinState = progress.spinState || { count: 0, lastDate: today };
  const adTracking = progress.adTracking || { lastSpinAdDate: today, dailySpinAdsWatched: 0 };

  // Handle daily reset
  useEffect(() => {
    let updateNeeded = false;
    let newSpinState = { ...spinState };
    let newAdTracking = { ...adTracking };

    if (spinState.lastDate !== today) {
      newSpinState = { count: 0, lastDate: today };
      updateNeeded = true;
    }

    if (adTracking.lastSpinAdDate !== today) {
      newAdTracking = { dailySpinAdsWatched: 0, lastSpinAdDate: today };
      updateNeeded = true;
    }

    if (updateNeeded) {
      setProgress(prev => ({
        ...prev,
        spinState: newSpinState,
        adTracking: newAdTracking
      }));
    }
  }, [today, spinState.lastDate, adTracking.lastSpinAdDate, setProgress]);

  const currentCount = spinState.lastDate === today ? spinState.count : 0;
  const isFree = currentCount === 0;
  const cost = isFree ? 0 : 100;

  const currentAdSpins = adTracking.lastSpinAdDate === today ? adTracking.dailySpinAdsWatched : 0;
  const adSpinsLeft = Math.max(0, AdConfig.DAILY_SPIN_AD_LIMIT - currentAdSpins);

  const [adLoading, setAdLoading] = useState(false);

  const executeSpin = (isAdSpin: boolean) => {
    setIsSpinning(true);
    setRewardToCollect(null);
    const shouldPlaySound = progress.settings?.sound ?? true;
    playSound('tap', shouldPlaySound);
    playVibration(50);
    const cancelSpinSound = playSpinSound(4000, shouldPlaySound);
    
    if (spinAudioRef.current) {
      spinAudioRef.current.pause();
      spinAudioRef.current.currentTime = 0;
      if (shouldPlaySound) {
        spinAudioRef.current.play().catch(() => {});
      }
    }
    
    // Deduct cost and update state immediately
    setProgress(prev => {
      const prevSpinState = prev.spinState || { count: 0, lastDate: today };
      const prevAdTracking = prev.adTracking || { dailySpinAdsWatched: 0, lastSpinAdDate: today };
      
      const newCount = prevSpinState.lastDate === today ? prevSpinState.count + 1 : 1;
      const newAdSpins = prevAdTracking.lastSpinAdDate === today ? prevAdTracking.dailySpinAdsWatched + (isAdSpin ? 1 : 0) : (isAdSpin ? 1 : 0);
      
      return {
        ...prev,
        coins: isAdSpin ? prev.coins : prev.coins - cost,
        spinState: { count: newCount, lastDate: today },
        adTracking: { dailySpinAdsWatched: newAdSpins, lastSpinAdDate: today }
      };
    });
    
    const randomSegmentIndex = Math.floor(Math.random() * SEGMENTS.length);
    const extraSpins = 5; 
    
    const centerAngle = (randomSegmentIndex + 0.5) * SEGMENT_ANGLE;
    const offset = (Math.random() - 0.5) * (SEGMENT_ANGLE * 0.7);
    
    const targetAngle = extraSpins * 360 + (360 - centerAngle) + offset;
    const currentBase = rotation - (rotation % 360);
    const finalRotation = currentBase + targetAngle;
    
    setRotation(finalRotation);

    setTimeout(() => {
      cancelSpinSound();
      const wonAmount = SEGMENTS[randomSegmentIndex];
      setRewardToCollect(wonAmount);
      setIsSpinning(false);
      
      if (spinAudioRef.current) {
        spinAudioRef.current.pause();
        spinAudioRef.current.currentTime = 0;
      }
      
      playSound('success', progress.settings?.sound ?? true);
      playVibration([50, 50, 50]);
    }, 4000);
  };

  const handleCoinSpin = () => {
    if (isSpinning) return;
    if (progress.coins < cost) {
      playSound('error', progress.settings?.sound ?? true);
      playVibration([50, 50, 50]);
      return;
    }
    executeSpin(false);
  };

  const handleAdSpin = async () => {
    if (isSpinning || adSpinsLeft <= 0 || adLoading) return;
    setAdLoading(true);
    const success = await UnityAds.showRewarded();
    setAdLoading(false);
    if (success) {
      executeSpin(true);
    }
  };

  const handleCollect = () => {
    if (rewardToCollect === null) return;
    
    playSound('success', progress.settings?.sound ?? true);
    setProgress(prev => ({
      ...prev,
      coins: prev.coins + rewardToCollect
    }));
    setRewardToCollect(null);
  };

  return (
    <div className="flex flex-col min-h-[100dvh] bg-[#FDFBF7] dark:bg-slate-950 p-6 transition-colors duration-300">
      {/* Header */}
      <div className="flex items-center justify-between mb-8 sticky top-0 z-20">
        <button 
          onClick={() => onNavigate('HOME')}
          className="w-12 h-12 bg-white dark:bg-slate-900 rounded-full flex items-center justify-center shadow-sm border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 active:scale-90 transition-all"
        >
          <ChevronLeft size={24} />
        </button>
        <div className="bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 px-4 py-2 rounded-2xl font-bold flex items-center gap-2 shadow-sm border border-amber-200 dark:border-amber-800/30">
          <Coins size={18} />
          <span>{progress.coins}</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full relative z-10">
        <h1 className="text-3xl font-black text-slate-800 dark:text-slate-200 mb-2">Lucky Spin</h1>
        <p className="text-slate-500 font-medium mb-10 bg-slate-200/50 dark:bg-slate-800/50 px-4 py-1.5 rounded-full text-sm">
          Ad Spins Left: <span className="font-bold text-slate-800 dark:text-slate-200">{adSpinsLeft} / {AdConfig.DAILY_SPIN_AD_LIMIT}</span>
        </p>

        {/* Wheel Container */}
        <div className="relative w-full aspect-square max-w-[320px] mb-12">
          {/* Pointer Arrow (Top) */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-10 z-20 drop-shadow-lg">
            <svg viewBox="0 0 24 24" fill="currentColor" className="text-rose-500 w-full h-full">
              <path d="M12 24L2 0h20L12 24z" />
            </svg>
          </div>

          {/* The Wheel */}
          <motion.div 
            className="w-full h-full rounded-full border-[10px] border-slate-800 dark:border-slate-200 shadow-2xl relative overflow-hidden bg-white"
            animate={{ rotate: rotation }}
            transition={{ duration: 4, ease: [0.15, 0.85, 0.2, 1] }}
          >
            {/* SVG implementation for better slice rendering */}
            <svg viewBox="-100 -100 200 200" className="w-full h-full absolute inset-0 -rotate-90">
              {SEGMENTS.map((amount, index) => {
                const angle = 360 / SEGMENTS.length;
                const startAngle = index * angle;
                const endAngle = (index + 1) * angle;
                
                const x1 = Math.cos(startAngle * Math.PI / 180) * 100;
                const y1 = Math.sin(startAngle * Math.PI / 180) * 100;
                const x2 = Math.cos(endAngle * Math.PI / 180) * 100;
                const y2 = Math.sin(endAngle * Math.PI / 180) * 100;
                
                const largeArcFlag = angle > 180 ? 1 : 0;
                
                const d = `M 0 0 L ${x1} ${y1} A 100 100 0 ${largeArcFlag} 1 ${x2} ${y2} Z`;
                
                const colors = ['#f87171', '#fbbf24', '#34d399', '#60a5fa', '#a78bfa', '#f472b6', '#38bdf8'];
                
                // For upright text, position text inside the slice 
                const midAngle = startAngle + (angle / 2);
                const textX = Math.cos(midAngle * Math.PI / 180) * 60;
                const textY = Math.sin(midAngle * Math.PI / 180) * 60;
                
                return (
                  <g key={index}>
                    <path d={d} fill={colors[index % colors.length]} stroke="rgba(255,255,255,0.2)" strokeWidth="2" />
                    <g transform={`translate(${textX}, ${textY}) rotate(${midAngle + 90})`}>
                      <text 
                        textAnchor="middle" 
                        dominantBaseline="middle" 
                        fill="white" 
                        fontSize={amount >= 100 ? "16" : "20"}
                        fontWeight="bold"
                        filter="drop-shadow(0px 2px 2px rgba(0,0,0,0.3))"
                      >
                        {amount} C
                      </text>
                    </g>
                  </g>
                );
              })}
            </svg>
            
            {/* Center dot */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-slate-800 dark:bg-slate-200 rounded-full border-4 border-white dark:border-slate-800 shadow-md"></div>
          </motion.div>
        </div>

        {/* Spin Buttons */}
        <div className="w-full flex flex-col gap-3 max-w-[280px]">
          <button
            onClick={handleCoinSpin}
            disabled={isSpinning || (progress.coins < cost && !isFree)}
            className={cn(
              "w-full py-4 rounded-2xl font-black text-xl shadow-xl transition-all flex justify-center items-center gap-3",
              isSpinning || (progress.coins < cost && !isFree)
                ? "bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 shadow-none cursor-not-allowed"
                : "bg-amber-400 dark:bg-amber-500 text-amber-950 dark:text-amber-900 shadow-amber-400/30 hover:bg-amber-300 dark:hover:bg-amber-400 active:scale-95"
            )}
          >
            {isSpinning ? "SPINNING..." : (isFree ? "FREE SPIN" : `SPIN (${cost} C)`)}
          </button>
          
          <button
            onClick={handleAdSpin}
            disabled={isSpinning || adSpinsLeft <= 0 || adLoading}
            className={cn(
              "w-full py-4 rounded-2xl font-black text-lg shadow-xl transition-all flex justify-center items-center gap-2 border-2",
              isSpinning || adSpinsLeft <= 0
                ? "bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-600 shadow-none cursor-not-allowed"
                : "bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800/50 text-indigo-700 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 active:scale-95 shadow-indigo-500/20"
            )}
          >
            <MonitorPlay size={20} />
            {adLoading ? "LOADING..." : adSpinsLeft <= 0 ? "COME BACK TOMORROW" : "WATCH AD TO SPIN"}
          </button>
        </div>
      </div>

      {/* Premium Reward Popup */}
      <AnimatePresence>
        {rewardToCollect !== null && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              className="bg-white dark:bg-slate-900 rounded-[2rem] p-8 max-w-sm w-full shadow-2xl flex flex-col items-center text-center relative overflow-hidden border border-amber-100 dark:border-slate-800"
            >
              {/* Sparkle background */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-200/40 via-transparent to-transparent pointer-events-none"></div>
              
              <div className="w-24 h-24 bg-gradient-to-tr from-amber-300 to-amber-500 rounded-full flex items-center justify-center mb-6 relative shadow-[0_0_30px_rgba(251,191,36,0.4)]">
                <Coins size={48} className="text-amber-950 drop-shadow-md relative z-10" />
                <div className="absolute inset-0 bg-white/20 rounded-full animate-ping opacity-50"></div>
              </div>
              
              <h2 className="text-sm font-black text-slate-400 dark:text-slate-500 tracking-[0.2em] mb-2 uppercase">COIN REWARD</h2>
              
              <div className="text-4xl font-black text-amber-500 drop-shadow-sm mb-8 flex items-center gap-2">
                <span>+</span>{rewardToCollect} <span className="text-2xl">COINS</span>
              </div>
              
              <button 
                onClick={handleCollect}
                className="w-full py-4 bg-amber-400 dark:bg-amber-500 hover:bg-amber-300 dark:hover:bg-amber-400 active:scale-95 transition-all rounded-2xl font-black text-amber-950 dark:text-amber-900 text-lg shadow-lg shadow-amber-400/30 flex items-center justify-center gap-2"
              >
                COLLECT
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
