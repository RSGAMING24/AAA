import { useState, useEffect } from 'react';
import { ViewState } from '../App';
import { PlayerProgress } from '../types';
import { ArrowLeft, CheckCircle2, Lock, MonitorPlay } from 'lucide-react';
import { cn, playSound, playVibration } from '../lib/utils';
import { motion } from 'motion/react';
import { UnityAds } from '../lib/unityAdsBridge';

interface DailyRewardProps {
  onNavigate: (v: ViewState, level?: number) => void;
  progress: PlayerProgress;
  setProgress: React.Dispatch<React.SetStateAction<PlayerProgress>>;
}

const getRewardAmount = (day: number) => {
  if (day === 1) return 5;
  if (day === 2) return 10;
  if (day === 3) return 12;
  if (day === 4) return 15;
  if (day === 5) return 20;
  if (day <= 10) return 30;
  if (day <= 20) return 40;
  if (day <= 50) return 50;
  if (day <= 99) return 75;
  return 200; // Day 100 jackpot
};

export function DailyReward({ onNavigate, progress, setProgress }: DailyRewardProps) {
  const [canClaim, setCanClaim] = useState(false);
  const [adLoading, setAdLoading] = useState(false);
  const currentDay = progress.dailyRewards?.currentDay || 1;
  const lastClaimDate = progress.dailyRewards?.lastClaimDate;

  useEffect(() => {
    // Check if we can claim today
    const today = new Date().toISOString().split('T')[0];
    if (lastClaimDate !== today) {
      setCanClaim(true);
    } else {
      setCanClaim(false);
    }
  }, [lastClaimDate]);

  const claimReward = async () => {
    if (!canClaim || currentDay > 100 || adLoading) return;
    
    setAdLoading(true);
    const success = await UnityAds.showRewarded();
    setAdLoading(false);
    
    if (!success) return;
    
    const reward = getRewardAmount(currentDay);
    const today = new Date().toISOString().split('T')[0];
    
    setProgress(prev => ({
      ...prev,
      coins: (prev.coins || 0) + reward,
      dailyRewards: {
        lastClaimDate: today,
        currentDay: prev.dailyRewards ? prev.dailyRewards.currentDay + 1 : 2
      }
    }));
    
    setCanClaim(false);
    playSound('success', progress.settings?.sound ?? true);
    playVibration(100);
  };

  // Create an array of 100 days
  const days = Array.from({ length: 100 }, (_, i) => i + 1);

  return (
    <div className="flex flex-col min-h-[100dvh] p-4 max-w-md mx-auto bg-[#FDFBF7] dark:bg-slate-950 transition-colors duration-300">
      <div className="flex items-center justify-between mb-6 pt-4 sticky top-0 bg-[#FDFBF7]/90 dark:bg-slate-950/90 backdrop-blur-md z-20 pb-4 border-b border-slate-200 dark:border-slate-800">
        <button 
          onClick={() => onNavigate('HOME')}
          className="p-3 hover:bg-slate-200/50 dark:hover:bg-slate-800/50 rounded-full transition-colors active:scale-95"
        >
          <ArrowLeft size={24} className="text-slate-800 dark:text-slate-200" />
        </button>
        <h1 className="font-bold text-xl text-slate-900 dark:text-slate-100 tracking-widest pl-6">DAILY REWARD</h1>
        <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-900/20 px-3 py-1.5 rounded-full border border-amber-200/50 dark:border-amber-700/50">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" className="text-amber-500">
            <circle cx="12" cy="12" r="10" />
            <text x="12" y="16.5" fontSize="12" fill="#FFF" textAnchor="middle" fontWeight="bold">C</text>
          </svg>
          <span className="text-amber-600 dark:text-amber-400 font-bold text-sm">{progress.coins || 0}</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-12 pr-2 custom-scrollbar">
        {currentDay <= 100 && (
          <div className="mb-8 p-6 bg-indigo-50 dark:bg-indigo-900/20 rounded-3xl border border-indigo-100 dark:border-indigo-800/50 flex flex-col items-center text-center">
            <h2 className="text-indigo-900 dark:text-indigo-300 font-bold text-lg mb-2">Day {currentDay} Reward</h2>
            <div className="flex items-center justify-center gap-3 bg-white dark:bg-slate-900 px-6 py-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 w-full mb-4">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor" className="text-amber-500 drop-shadow-sm">
                <circle cx="12" cy="12" r="10" />
                <text x="12" y="16.5" fontSize="14" fill="#FFF" textAnchor="middle" fontWeight="bold">C</text>
              </svg>
              <span className="text-3xl font-black text-slate-800 dark:text-slate-100">{getRewardAmount(currentDay)}</span>
            </div>
            <button
              onClick={claimReward}
              disabled={!canClaim || adLoading}
              className={cn(
                "w-full py-4 rounded-2xl font-bold text-lg transition-all active:scale-95 flex items-center justify-center gap-2",
                canClaim 
                  ? "bg-indigo-600 text-white shadow-md hover:bg-indigo-700 disabled:opacity-70 disabled:cursor-wait" 
                  : "bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed"
              )}
            >
              {canClaim ? (
                <>
                  <MonitorPlay size={20} />
                  {adLoading ? "LOADING..." : "WATCH AD TO CLAIM"}
                </>
              ) : "COME BACK TOMORROW"}
            </button>
          </div>
        )}

        <div className="grid grid-cols-3 gap-3">
          {days.map((day, i) => {
            const status = day < currentDay ? 'collected' : day === currentDay ? (canClaim ? 'today' : 'collected') : 'locked';
            const reward = getRewardAmount(day);
            
            return (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: Math.min(i, 30) * 0.02 }}
                key={day}
                className={cn(
                  "flex flex-col items-center justify-center p-3 rounded-2xl border-2 transition-all h-28 relative overflow-hidden",
                  status === 'collected' && "bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-70",
                  status === 'today' && "bg-indigo-50 dark:bg-indigo-900/30 border-indigo-500 dark:border-indigo-500 shadow-sm shadow-indigo-100 dark:shadow-none scale-105 z-10",
                  status === 'locked' && "bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800"
                )}
              >
                {status === 'collected' && (
                  <div className="absolute inset-0 bg-white/40 dark:bg-slate-900/60 z-10 flex items-center justify-center">
                    <CheckCircle2 size={32} className="text-green-500" />
                  </div>
                )}
                
                <span className={cn(
                  "text-xs font-bold mb-2",
                  status === 'today' ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 dark:text-slate-500"
                )}>
                  DAY {day}
                </span>
                
                <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor" className={cn(
                  "mb-1",
                  status === 'locked' ? "text-slate-300 dark:text-slate-600" : "text-amber-500"
                )}>
                  <circle cx="12" cy="12" r="10" />
                  <text x="12" y="16.5" fontSize="12" fill={status === 'locked' ? "currentColor" : "#FFF"} textAnchor="middle" fontWeight="bold">C</text>
                </svg>
                
                <span className={cn(
                  "font-black text-sm",
                  status === 'locked' ? "text-slate-300 dark:text-slate-600" : "text-slate-700 dark:text-slate-200"
                )}>
                  {reward}
                </span>
                
                {status === 'locked' && (
                  <Lock size={12} className="absolute bottom-2 right-2 text-slate-300 dark:text-slate-700" />
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: #cbd5e1;
          border-radius: 10px;
        }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: #334155;
        }
      `}</style>
    </div>
  );
}
