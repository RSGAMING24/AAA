import { Direction } from '../types';

interface ArrowSvgProps {
  length: number;
  direction: Direction;
  cellSize: number;
  strokeColor: string;
}

export function ArrowSvg({ length, direction, cellSize, strokeColor }: ArrowSvgProps) {
  const getRotation = (dir: Direction) => {
    switch (dir) {
      case 'RIGHT': return 0;
      case 'DOWN': return 90;
      case 'LEFT': return 180;
      case 'UP': return -90;
      default: return 0;
    }
  };

  const padding = 6;
  const headLength = 12;
  const strokeWidth = 4;
  const W = length * cellSize;
  const endX = W - padding - 2;
  const startX = padding + 2;
  const centerY = cellSize / 2;

  return (
    <div
      style={{
        position: 'absolute',
        width: W,
        height: cellSize,
        right: 0,
        top: 0,
        transformOrigin: `calc(100% - ${cellSize / 2}px) 50%`,
        transform: `rotate(${getRotation(direction)}deg)`,
        pointerEvents: 'auto', // let clicks bubble to parent
      }}
    >
      <svg width="100%" height="100%" className="overflow-visible">
        {/* Body */}
        <line 
          x1={startX} 
          y1={centerY} 
          x2={endX} 
          y2={centerY} 
          stroke={strokeColor} 
          strokeWidth={strokeWidth} 
          strokeLinecap="round" 
        />
        {/* Head */}
        <polyline 
          points={`${endX - headLength},${centerY - 8} ${endX},${centerY} ${endX - headLength},${centerY + 8}`} 
          fill="none" 
          stroke={strokeColor} 
          strokeWidth={strokeWidth} 
          strokeLinecap="round" 
          strokeLinejoin="round" 
        />
      </svg>
    </div>
  );
}
