import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PlayerProgress } from '../types';
import { cn, playSound } from '../lib/utils';
import { Sparkles } from 'lucide-react';
import { UnityAds } from '../lib/unityAdsBridge';

interface MysteryGiftProps {
  progress: PlayerProgress;
  setProgress: React.Dispatch<React.SetStateAction<PlayerProgress>>;
}

export function MysteryGift({ progress, setProgress }: MysteryGiftProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isOpened, setIsOpened] = useState(false);
  const [rewardAmount, setRewardAmount] = useState(0);

  useEffect(() => {
    // Check if enough time has passed since last gift (e.g. 5 minutes)
    const COOLDOWN = 5 * 60 * 1000;
    const lastTime = progress.lastMysteryGiftTime || 0;
    const now = Date.now();
    
    if (now - lastTime >= COOLDOWN) {
      setIsVisible(true);
    }

    const interval = setInterval(() => {
      const currentTime = Date.now();
      if (!isVisible && currentTime - (progress.lastMysteryGiftTime || 0) >= COOLDOWN) {
        setIsVisible(true);
      }
    }, 10000); // check every 10 seconds

    return () => clearInterval(interval);
  }, [progress.lastMysteryGiftTime, isVisible]);

  const [adLoading, setAdLoading] = useState(false);

  const handleOpen = async () => {
    if (isOpened || adLoading) return;
    
    setAdLoading(true);
    const success = await UnityAds.showRewarded();
    setAdLoading(false);
    
    if (!success) return;
    
    setIsOpened(true);
    playSound('tap', progress.settings?.sound ?? true);

    // Determine reward: 10 Coins = Common, 15 Coins = Rare, 20 Coins = Maximum/Rarest
    const rand = Math.random();
    let amount = 10;
    if (rand > 0.9) {
      amount = 20;
    } else if (rand > 0.7) {
      amount = 15;
    }

    setRewardAmount(amount);

    // After animation, add coins and dismiss
    setTimeout(() => {
      playSound('success', progress.settings?.sound ?? true);
      setProgress(prev => ({
        ...prev,
        coins: prev.coins + amount,
        lastMysteryGiftTime: Date.now()
      }));

      setTimeout(() => {
        setIsVisible(false);
        setIsOpened(false);
      }, 1500);
    }, 1500);
  };

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ scale: 0, y: 50, rotate: -10 }}
      animate={{ scale: 1, y: 0, rotate: [0, -5, 5, -5, 5, 0] }}
      transition={{ 
        type: 'spring', damping: 12,
        rotate: { repeat: Infinity, duration: 2, repeatDelay: 3 }
      }}
      className="absolute -top-16 right-0 z-50 cursor-pointer"
      onClick={handleOpen}
    >
      {/* Glow effect */}
      <div className="absolute inset-0 bg-yellow-400 blur-xl opacity-40 rounded-full animate-pulse" />
      
      {/* 3D Scene */}
      <div className="relative w-16 h-16" style={{ perspective: '500px' }}>
        <motion.div 
          className="w-full h-full relative"
          animate={{ rotateY: [0, 360] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Box Bottom (40x40x40) */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10" style={{ transformStyle: 'preserve-3d' }}>
             <div className="absolute inset-0 bg-rose-500 border border-rose-600 shadow-inner flex items-center justify-center" style={{ transform: 'translateZ(20px)' }}><div className="w-2 h-full bg-yellow-400" /></div>
             <div className="absolute inset-0 bg-rose-600 border border-rose-700 shadow-inner flex items-center justify-center" style={{ transform: 'rotateY(90deg) translateZ(20px)' }}><div className="w-2 h-full bg-yellow-400" /></div>
             <div className="absolute inset-0 bg-rose-600 border border-rose-700 shadow-inner flex items-center justify-center" style={{ transform: 'rotateY(180deg) translateZ(20px)' }}><div className="w-2 h-full bg-yellow-400" /></div>
             <div className="absolute inset-0 bg-rose-500 border border-rose-600 shadow-inner flex items-center justify-center" style={{ transform: 'rotateY(-90deg) translateZ(20px)' }}><div className="w-2 h-full bg-yellow-400" /></div>
             <div className="absolute inset-0 bg-rose-700" style={{ transform: 'rotateX(90deg) translateZ(20px)' }} />
             <div className="absolute inset-0 bg-rose-700" style={{ transform: 'rotateX(-90deg) translateZ(20px)' }} />
          </div>

          {/* Box Lid (44x12x44) */}
          <motion.div 
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-3 origin-bottom"
            animate={isOpened ? { y: -30, rotateX: 45, rotateZ: 20, rotateY: 10, opacity: 0 } : { y: -20 }}
            transition={{ duration: 0.8, ease: "backOut" }}
            style={{ transformStyle: 'preserve-3d' }}
          >
             <div className="absolute inset-0 bg-rose-400 border border-rose-500 flex items-center justify-center" style={{ transform: 'translateZ(22px)' }}><div className="w-2 h-full bg-yellow-300" /></div>
             <div className="absolute inset-0 bg-rose-500 border border-rose-600 flex items-center justify-center" style={{ transform: 'rotateY(90deg) translateZ(22px)' }}><div className="w-2 h-full bg-yellow-300" /></div>
             <div className="absolute inset-0 bg-rose-500 border border-rose-600 flex items-center justify-center" style={{ transform: 'rotateY(180deg) translateZ(22px)' }}><div className="w-2 h-full bg-yellow-300" /></div>
             <div className="absolute inset-0 bg-rose-400 border border-rose-500 flex items-center justify-center" style={{ transform: 'rotateY(-90deg) translateZ(22px)' }}><div className="w-2 h-full bg-yellow-300" /></div>
             
             {/* Top Face */}
             <div className="absolute left-0 top-1/2 -translate-y-1/2 w-11 h-11 bg-rose-400 border border-rose-500 flex items-center justify-center" style={{ transform: 'rotateX(90deg) translateZ(6px)', transformStyle: 'preserve-3d' }}>
                 <div className="w-full h-2 bg-yellow-300 absolute" />
                 <div className="h-full w-2 bg-yellow-300 absolute" />
                 {/* Bow ribbons */}
                 <div className="absolute w-3 h-3 bg-yellow-400 rounded-full border border-yellow-500 shadow-lg" style={{ transform: 'translateZ(2px) translateX(-4px)' }} />
                 <div className="absolute w-3 h-3 bg-yellow-400 rounded-full border border-yellow-500 shadow-lg" style={{ transform: 'translateZ(2px) translateX(4px)' }} />
                 <div className="absolute w-2 h-2 bg-yellow-500 rounded-full border border-yellow-600 shadow-lg" style={{ transform: 'translateZ(3px)' }} />
             </div>
             
             {/* Bottom Face */}
             <div className="absolute left-0 top-1/2 -translate-y-1/2 w-11 h-11 bg-rose-600" style={{ transform: 'rotateX(-90deg) translateZ(6px)' }} />
          </motion.div>
          
        </motion.div>
        
        {/* Coin Pop out */}
        <AnimatePresence>
          {isOpened && (
             <motion.div 
               initial={{ y: 0, scale: 0, opacity: 0 }}
               animate={{ y: -60, scale: [1, 1.2, 1], opacity: 1 }}
               exit={{ y: -100, opacity: 0 }}
               transition={{ duration: 1, ease: "easeOut" }}
               className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center z-50 pointer-events-none"
             >
                <div className="relative">
                   <Sparkles className="absolute -inset-4 text-yellow-400 w-16 h-16 animate-ping opacity-50" />
                   <div className="w-10 h-10 bg-yellow-400 rounded-full border-2 border-yellow-200 flex items-center justify-center shadow-[0_0_15px_rgba(250,204,21,0.8)] z-10 relative">
                     <span className="text-yellow-900 font-black text-xs">C</span>
                   </div>
                </div>
                <motion.div 
                  initial={{ y: 10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="mt-2 text-yellow-400 font-black text-xl whitespace-nowrap drop-shadow-md"
                  style={{ textShadow: '0 2px 4px rgba(0,0,0,0.5)' }}
                >
                  +{rewardAmount}
                </motion.div>
             </motion.div>
          )}
        </AnimatePresence>
        
        {!isOpened && (
          <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[10px] font-black tracking-wider px-2 py-0.5 rounded-full shadow-md whitespace-nowrap border border-indigo-400">
            {adLoading ? "LOADING..." : "WATCH AD"}
          </div>
        )}
      </div>
    </motion.div>
  );
}
