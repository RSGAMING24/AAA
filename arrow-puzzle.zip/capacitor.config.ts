interface CapacitorConfig {
  appId: string;
  appName: string;
  webDir: string;
  bundledWebRuntime?: boolean;
}

const config: CapacitorConfig = {
  appId: 'com.example.arrowpuzzle',
  appName: 'Arrow Puzzle',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
